/***** API Developer's Code *******/
#include <cstdio>

void PrintA(const char* s);
void PrintW(const wchar_t* ws);

void PrintA(const char* s) {
	printf("%s", s);
}

void PrintW(const wchar_t* ws) {
	printf("%S", ws);
}

/* Application Developer's Code *****/
int main() {
	PrintA("Hello, World\n");
}
