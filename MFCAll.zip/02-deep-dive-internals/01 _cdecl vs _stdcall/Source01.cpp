int Add(int u, int v);

int main() {
	int a = 1, b = 2, c = 0;
	c = Add(a, b);
}

int Add(int u, int v) {
	return u + v;
}
