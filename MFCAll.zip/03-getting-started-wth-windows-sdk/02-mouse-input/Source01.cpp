#include <sstream>
#include <Windows.h>
using namespace std;

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// Entry point for the Windows Application is WinMain or wWinMain
// Windows NT supports UNICODE character system from the ground up
int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nShowCmd) {
	wchar_t szAppName[] = L"MainWnd";
	WNDCLASSW wndclass;
	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wndclass.lpszMenuName = NULL;
	wndclass.lpszClassName = szAppName;

	if (!RegisterClassW(&wndclass)) {
		MessageBoxW(NULL, L"This program requires Windows NT!", szAppName, MB_ICONERROR);
		return 0;
	}

	HWND hwnd = CreateWindowExW(0, szAppName, L"The Hello Program", WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, NULL, hInstance, NULL);

	ShowWindow(hwnd, nShowCmd);

	UpdateWindow(hwnd);

	MSG msg;

	while (GetMessageW(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessageW(&msg);
	}

	return msg.wParam;
}

void WINAPI OutputDbgString(LPCTSTR message, WPARAM wParam, LPARAM lParam) {
	wstringstream ss;
	ss << L"Message: " << message
		<< L" Control Key: " << ((wParam & MK_CONTROL) == 0 ? L"Up" : L"Down")
		<< L" Shift Key: " << ((wParam & MK_SHIFT) == 0 ? L"Up" : L"Down")
		<< L" @ x: " << LOWORD(lParam) << L" y: " << HIWORD(lParam) << endl;
	OutputDebugStringW(ss.str().c_str());
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	switch (message) {
	case WM_LBUTTONDOWN:
		OutputDbgString(L"WM_LBUTTONDOWN", wParam, lParam);
		break;
	case WM_LBUTTONUP:
		OutputDbgString(L"WM_LBUTTONUP", wParam, lParam);
		break;
	case WM_NCLBUTTONDOWN:
		OutputDbgString(L"WM_NCLBUTTONDOWN", wParam, lParam);
		break;
	case WM_NCLBUTTONUP:
		OutputDbgString(L"WM_NCLBUTTONUP", wParam, lParam);
		break;
	case WM_MOUSEMOVE:
		OutputDbgString(L"WM_MOUSEMOVE", wParam, lParam);
		break;
	case WM_NCMOUSEMOVE:
		OutputDbgString(L"WM_NCMOUSEMOVE", wParam, lParam);
		break;
	case WM_CLOSE:
		DestroyWindow(hWnd);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProcW(hWnd, message, wParam, lParam);
	}
	return 0;
}