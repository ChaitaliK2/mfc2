#include "pch.h"
#include "MouseAndKeyboardInputApp.h"
#include "MainFrame.h"

CMouseAndKeyboardInputApp theApp;
BOOL CMouseAndKeyboardInputApp::InitInstance()
{
	CMainFrame* pFrame = new CMainFrame();
	pFrame->Create(NULL, TEXT("Mouse and keyboard input Demo"));
	pFrame->ShowWindow(m_nCmdShow);
	m_pMainWnd = pFrame;
	return TRUE;
}