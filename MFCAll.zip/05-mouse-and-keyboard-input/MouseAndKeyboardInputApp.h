#pragma once
class CMouseAndKeyboardInputApp :
    public CWinApp
{
public:
    BOOL InitInstance() override;
};

