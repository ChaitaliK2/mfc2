#include "pch.h"
#include "MainFrame.h"

BEGIN_MESSAGE_MAP(CMainFrame,CFrameWnd)
	ON_WM_LBUTTONDOWN()
	ON_WM_KEYDOWN()
	ON_WM_CHAR()
END_MESSAGE_MAP()

void CMainFrame::OnLButtonDown(UINT nFlags, CPoint point)
{
	TRACE(TEXT("Mouse left button is down, x:%d, y:%d\n"), point.x, point.y);
	TRACE(TEXT("Control key:%s\n"), (nFlags & MK_CONTROL ? TEXT("Down") : TEXT("Up")));
	TRACE(TEXT("Shift key:%s\n"), (nFlags & MK_SHIFT ? TEXT("Down") : TEXT("Up")));
}

void CMainFrame::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	TRACE(TEXT("Virtual key code:%d\n"), nChar);
}

void CMainFrame::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	TRACE(TEXT("charcode :%d\n"), nChar);
}