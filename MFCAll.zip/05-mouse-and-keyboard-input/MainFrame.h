#pragma once
class CMainFrame :
    public CFrameWnd
{

    DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnLButtonDown(UINT nFlags,CPoint point);
    afx_msg void OnKeyDown(UINT nChar,UINT nRepCnt,UINT nFlags);
    afx_msg void OnChar(UINT nChar,UINT nRepCnt,UINT nFlags);
};

