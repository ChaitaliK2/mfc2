#pragma once
class CPaintWnd :
    public CFrameWnd
{
};

