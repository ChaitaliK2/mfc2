#include "pch.h"
#include "PaintApp.h"
#include "PaintWnd.h"
#include "resource.h"

BEGIN_MESSAGE_MAP(CPaintApp, CWinApp)

END_MESSAGE_MAP()

CPaintApp Cpaint;
BOOL CPaintApp::InitInstance()
{
	CFrameWnd* pFrame = new CFrameWnd();
	pFrame->LoadFrame(IDR_PAINT_APP);
	pFrame->ShowWindow(m_nCmdShow);
	m_pMainWnd = pFrame;
	return TRUE;
}