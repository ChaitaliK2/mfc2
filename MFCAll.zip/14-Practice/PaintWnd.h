#pragma once
class CPaintWnd : public CFrameWnd
{
    DECLARE_MESSAGE_MAP()
public:
    afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
    void OnActionRectangle();
    void OnActionEclipse();
    void OnActionLine();
    void OnActionBorderRed();
    void OnActionBorderGreen();
    void OnActionBorderBlue();
    void OnActionBorder1Picxel();
    void OnActionBorder2Picxel();
    void OnActionBorder3Picxel();
    void OnActionBrushRed();
    void OnActionBrushGreen();
    void OnActionBrushBlue();
    afx_msg void OnContextMenu(CWnd* pWnd, CPoint pos);
    afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
    afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
    afx_msg void OnPaint();

private:
    CMenu m_contextMenu;
    CPoint m_p1;
    CPoint m_p2;
    int m_shape;
    bool m_redBorder;
    bool m_greenBorder;
    bool m_blueBorder;
    int m_pixcel;
    bool m_redBrush;
    bool m_greenBrush;
    bool m_blueBrush;
};

