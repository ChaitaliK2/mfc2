//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by 14-Practice.rc
//
#define IDR_MENU1                       101
#define IDR_ACCELERATOR1                102
#define IDI_ICON1                       103
#define IDS_CAPTION                     104
#define IDR_APP_RES                     105
#define IDR_MENU2                       106
#define IDD_CDLG                        107
#define ID_PAINT_RECTANGLE              40001
#define ID_PAINT_ECLIPSE                40002
#define ID_PAINT_LINE                   40003
#define ID_BORDER_RED                   40005
#define ID_BORDER_GREEN                 40006
#define ID_BORDER_BLUE                  40007
#define ID_BORDER_1PIXCEL               40008
#define ID_BORDER_2PICXEL               40009
#define ID_BORDER_3PICXEL               40010
#define ID_BRUSH_RED                    40011
#define ID_BRUSH_GREEN                  40012
#define ID_BRUSH_BLUE                   40013
#define ID_RECTANGLE_ECLIPSE            40019
#define ID_RECTANGLE_LINE               40020
#define ID_CONTEXTMENU_REACTANGLE       40021
#define ID_CONTEXTMENU_ECLIPSE          40022
#define ID_CONTEXTMENU_LINE             40023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40024
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
