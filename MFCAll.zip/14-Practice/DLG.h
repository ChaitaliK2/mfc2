#pragma once


// CDLG dialog

class CDLG : public CDialog
{
	DECLARE_DYNAMIC(CDLG)

public:
	CDLG(CWnd* pParent = nullptr);   // standard constructor
	virtual ~CDLG();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CDLG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
};
