#pragma once
class CPaintApp :
    public CWinApp
{
    DECLARE_MESSAGE_MAP()
public:
    BOOL InitInstance() override;
};

