#include "pch.h"
#include "PaintWnd.h"
#include "resource.h"

BEGIN_MESSAGE_MAP(CPaintWnd, CFrameWnd)
    ON_WM_CREATE()
    ON_COMMAND(ID_PAINT_RECTANGLE,&CPaintWnd::OnActionRectangle)
    ON_COMMAND(ID_PAINT_ECLIPSE, &CPaintWnd::OnActionEclipse)
    ON_COMMAND(ID_PAINT_LINE, &CPaintWnd::OnActionLine)
    ON_COMMAND(ID_BORDER_RED, &CPaintWnd::OnActionBorderRed)
    ON_COMMAND(ID_BORDER_GREEN, &CPaintWnd::OnActionBorderGreen)
    ON_COMMAND(ID_BORDER_BLUE, &CPaintWnd::OnActionBorderBlue)
    ON_COMMAND(ID_BORDER_1PIXCEL, &CPaintWnd::OnActionBorder1Picxel)
    ON_COMMAND(ID_BORDER_2PICXEL, &CPaintWnd::OnActionBorder2Picxel)
    ON_COMMAND(ID_BORDER_3PICXEL, &CPaintWnd::OnActionBorder3Picxel)
    ON_COMMAND(ID_BRUSH_RED, &CPaintWnd::OnActionBrushRed)
    ON_COMMAND(ID_BRUSH_GREEN, &CPaintWnd::OnActionBrushGreen)
    ON_COMMAND(ID_BRUSH_BLUE, &CPaintWnd::OnActionBrushBlue)
    ON_COMMAND(ID_CONTEXTMENU_REACTANGLE, &CPaintWnd::OnActionRectangle)
    ON_COMMAND(ID_CONTEXTMENU_ECLIPSE, &CPaintWnd::OnActionEclipse)
    ON_COMMAND(ID_CONTEXTMENU_LINE, &CPaintWnd::OnActionLine)
    ON_WM_CONTEXTMENU()
    ON_WM_LBUTTONDOWN()
    ON_WM_LBUTTONUP()
    ON_WM_PAINT()

END_MESSAGE_MAP()


int CPaintWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
    if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
        return -1;

    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
    pActionMenu->CheckMenuRadioItem(ID_BORDER_1PIXCEL, ID_BORDER_3PICXEL, ID_BORDER_1PIXCEL, MF_BYCOMMAND);
    CMenu* pActionMenu1 = pMenu->GetSubMenu(0);
    pActionMenu1->CheckMenuRadioItem(ID_PAINT_RECTANGLE, ID_PAINT_LINE, ID_PAINT_RECTANGLE, MF_BYCOMMAND);
    m_contextMenu.LoadMenu(IDR_MENU2);

    return 0;
}

void CPaintWnd::OnContextMenu(CWnd* pWnd, CPoint pos)
{
    m_contextMenu.GetSubMenu(0)->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTALIGN | TPM_LEFTBUTTON, pos.x, pos.y, pWnd);
}
void CPaintWnd::OnActionRectangle()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu1 = pMenu->GetSubMenu(0);
    m_shape = 1;
    pActionMenu1->CheckMenuRadioItem(ID_PAINT_RECTANGLE, ID_PAINT_LINE, ID_PAINT_RECTANGLE, MF_BYCOMMAND);
}

void CPaintWnd::OnActionEclipse()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu1 = pMenu->GetSubMenu(0);
    m_shape = 2;
    pActionMenu1->CheckMenuRadioItem(ID_PAINT_RECTANGLE, ID_PAINT_LINE, ID_PAINT_ECLIPSE, MF_BYCOMMAND);
}

void CPaintWnd::OnActionLine()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu1 = pMenu->GetSubMenu(0);
    m_shape = 3;
    pActionMenu1->CheckMenuRadioItem(ID_PAINT_RECTANGLE, ID_PAINT_LINE, ID_PAINT_LINE, MF_BYCOMMAND);
}

void CPaintWnd::OnActionBorderRed()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
     m_redBorder= TRUE;
    UINT checkState = pActionMenu->GetMenuState(ID_BORDER_RED, MF_BYCOMMAND);
    if (checkState & MF_CHECKED)
    {
        m_redBorder = FALSE;
        pActionMenu->CheckMenuItem(ID_BORDER_RED, MF_UNCHECKED | MF_BYCOMMAND);
    }
    else
    {
        m_redBorder = TRUE;
        pActionMenu->CheckMenuItem(ID_BORDER_RED, MF_CHECKED | MF_BYCOMMAND);
    }
}

void CPaintWnd::OnActionBorderGreen()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
     m_greenBorder = TRUE;
    UINT checkState = pActionMenu->GetMenuState(ID_BORDER_GREEN, MF_BYCOMMAND);
    if (checkState & MF_CHECKED)
    {
        m_greenBorder = FALSE;
        pActionMenu->CheckMenuItem(ID_BORDER_GREEN, MF_UNCHECKED | MF_BYCOMMAND);
    }
    else
    {
        m_greenBorder = TRUE;
        pActionMenu->CheckMenuItem(ID_BORDER_GREEN, MF_CHECKED | MF_BYCOMMAND);
    }
}

void CPaintWnd::OnActionBorderBlue()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
    m_blueBorder= TRUE;
    UINT checkState = pActionMenu->GetMenuState(ID_BORDER_BLUE, MF_BYCOMMAND);
    if (checkState & MF_CHECKED)
    {
        m_blueBorder = FALSE;
        pActionMenu->CheckMenuItem(ID_BORDER_BLUE, MF_UNCHECKED | MF_BYCOMMAND);
    }
    else
    {
        m_blueBorder = TRUE;
        pActionMenu->CheckMenuItem(ID_BORDER_BLUE, MF_CHECKED | MF_BYCOMMAND);
    }
}

void CPaintWnd::OnActionBorder1Picxel()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
    m_pixcel = 1;
    pActionMenu->CheckMenuRadioItem(ID_BORDER_1PIXCEL, ID_BORDER_3PICXEL, ID_BORDER_1PIXCEL, MF_BYCOMMAND);
}

void CPaintWnd::OnActionBorder2Picxel()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
    m_pixcel = 2;
    pActionMenu->CheckMenuRadioItem(ID_BORDER_1PIXCEL, ID_BORDER_3PICXEL, ID_BORDER_2PICXEL, MF_BYCOMMAND);
}

void CPaintWnd::OnActionBorder3Picxel()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
    m_pixcel = 3;
    pActionMenu->CheckMenuRadioItem(ID_BORDER_1PIXCEL, ID_BORDER_3PICXEL, ID_BORDER_3PICXEL, MF_BYCOMMAND);
}

void CPaintWnd::OnActionBrushRed()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(2);
    m_redBrush = TRUE;
    UINT checkState = pActionMenu->GetMenuState(ID_BRUSH_RED, MF_BYCOMMAND);
    if (checkState & MF_CHECKED)
    {
        m_redBrush = FALSE;
        pActionMenu->CheckMenuItem(ID_BRUSH_RED, MF_UNCHECKED | MF_BYCOMMAND);
    }
    else
    {
        m_redBrush = TRUE;
        pActionMenu->CheckMenuItem(ID_BRUSH_RED, MF_CHECKED | MF_BYCOMMAND);
    }
}

void CPaintWnd::OnActionBrushGreen()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(2);
    m_greenBrush = TRUE;
    UINT checkState = pActionMenu->GetMenuState(ID_BRUSH_GREEN, MF_BYCOMMAND);
    if (checkState & MF_CHECKED)
    {
        m_greenBrush = FALSE;
        pActionMenu->CheckMenuItem(ID_BRUSH_GREEN, MF_UNCHECKED | MF_BYCOMMAND);
    }
    else
    {
        m_greenBrush = TRUE;
        pActionMenu->CheckMenuItem(ID_BRUSH_GREEN, MF_CHECKED | MF_BYCOMMAND);
    }
}

void CPaintWnd::OnActionBrushBlue()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(2);
    m_blueBrush = TRUE;
    UINT checkState = pActionMenu->GetMenuState(ID_BRUSH_BLUE, MF_BYCOMMAND);
    if (checkState & MF_CHECKED)
    {
        m_blueBrush = FALSE;
        pActionMenu->CheckMenuItem(ID_BRUSH_BLUE, MF_UNCHECKED | MF_BYCOMMAND);
    }
    else
    {
        m_blueBrush = TRUE;
        pActionMenu->CheckMenuItem(ID_BRUSH_BLUE, MF_CHECKED | MF_BYCOMMAND);
    }
}


void CPaintWnd::OnLButtonDown(UINT nFlags, CPoint point)
{
    m_p1 = point;
}

void CPaintWnd::OnLButtonUp(UINT nFlags, CPoint point)
{
    m_p2 = point;
    Invalidate();
    UpdateWindow();
}

void CPaintWnd::OnPaint()
{
    CPaintDC dc(this);
    COLORREF m_borderColor;
    COLORREF m_brushColor;
    m_borderColor = RGB(m_redBorder ? 255 : 0, m_greenBorder ? 255 : 0, m_blueBorder ? 255 : 0);
    m_brushColor = RGB(m_redBrush ? 255 : 0, m_greenBrush ? 255 : 0, m_blueBrush ? 255 : 0);
    CPen Pen(PS_SOLID, m_pixcel, m_borderColor);
    CBrush Brush(m_brushColor);

    CBrush* pOrgBrush = dc.SelectObject(&Brush);
    CPen* pOrgPen = dc.SelectObject(&Pen);

    switch (m_shape)
    {
    case 1:
        dc.Rectangle(m_p1.x, m_p1.y, m_p2.x, m_p2.y);
        break;
    case 2:
        dc.Ellipse(m_p1.x, m_p1.y, m_p2.x, m_p2.y);
        break;
    case 3:
        dc.MoveTo(m_p1);
        dc.LineTo(m_p2);
        break;
    }
    dc.SelectObject(pOrgPen);
    dc.SelectObject(pOrgBrush);
}