// DLG.cpp : implementation file
//

#include "pch.h"
#include "DLG.h"
#include "afxdialogex.h"


// CDLG dialog

IMPLEMENT_DYNAMIC(CDLG, CDialog)

CDLG::CDLG(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_CDLG, pParent)
{

}

CDLG::~CDLG()
{
}

void CDLG::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDLG, CDialog)
END_MESSAGE_MAP()


// CDLG message handlers
