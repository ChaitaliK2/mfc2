#include "pch.h"
#include "PaintApp.h"
#include "PaintWnd.h"
#include "resource.h"

BEGIN_MESSAGE_MAP(CPaintApp, CWinApp)
	

END_MESSAGE_MAP()

CPaintApp theApp;


BOOL CPaintApp::InitInstance()
{
	CPaintWnd* pFrame = new CPaintWnd();
	//pFrame->Create(NULL, TEXT("hello"));
	pFrame->LoadFrame(IDR_APP_RES);
	pFrame->ShowWindow(m_nCmdShow);
	m_pMainWnd = pFrame;
	return TRUE;
}