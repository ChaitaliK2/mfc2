//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by My08usingdialogs.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_My08usingdialogsTYPE        130
#define IDD_MODALDLG                    310
#define IDD_MODELESSDLG                 311
#define IDD_ADVANCEDCONTROLSDLG         312
#define IDC_EDIT_X1                     1000
#define IDC_EDIT_Y1                     1001
#define IDC_EDIT_X2                     1002
#define IDC_EDIT_Y2                     1003
#define IDOK1                           1004
#define IDCANCEL1                       1005
#define IDAPPLY                         1006
#define IDC_PROGRESS1                   1007
#define IDC_SLIDER1                     1008
#define ID_DIALOG_MODEL                 32771
#define ID_DIALOG_MODELESS              32772
#define ID_DIALOG_COMMANDIALOG          32773
#define ID_DIALOG_ADVANCEDCONTROLS      32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        313
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           313
#endif
#endif
