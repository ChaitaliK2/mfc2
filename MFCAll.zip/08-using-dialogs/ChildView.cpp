
// ChildView.cpp : implementation of the CChildView class
//

#include "pch.h"
#include "framework.h"
#include "UsingDialogsApp.h"
#include "ModelDlg.h"
#include "ChildView.h"
#include "AdvancedControlsDlg.h"
#include "resource.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView():m_x1(0),m_y1(0),m_x2(0),m_y2(0),m_ModelessDlg(this),m_color(RGB(255,255,255))
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_COMMAND(ID_DIALOG_MODEL, &CChildView::OnDialogModel)
	ON_COMMAND(ID_DIALOG_MODELESS, &CChildView::OnDialogModeless)
	ON_COMMAND(ID_DIALOG_COMMANDIALOG, &CChildView::OnDialogCommonDialog)
	ON_COMMAND(ID_DIALOG_ADVANCEDCONTROLS, &CChildView::OnDialogAdvancedControls)
	ON_MESSAGE(WM_INPUTREADY, &CChildView::OnInputReady)
END_MESSAGE_MAP()



// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(nullptr, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), nullptr);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CBrush brush(m_color);
	CBrush* pOrgBrush = dc.SelectObject(&brush);
	dc.Rectangle(m_x1, m_y1, m_x2, m_y2);
	dc.SelectObject(pOrgBrush);
}



void CChildView::OnDialogModel()
{
	// TODO: Add your command handler code here
	CModelDlg modalDlg(m_x1,m_y1,m_x2,m_y2);
	if (modalDlg.DoModal() == IDOK1)
	{
		m_x1 = modalDlg.m_x1;
		m_y1 = modalDlg.m_y1;
		m_x2 = modalDlg.m_x2;
		m_y2 = modalDlg.m_y2;
		Invalidate();
	}
}


void CChildView::OnDialogModeless()
{
	// TODO: Add your command handler code here
	if(m_ModelessDlg.GetSafeHwnd()==NULL)
		m_ModelessDlg.Create(IDD_MODELESSDLG);
	m_ModelessDlg.CenterWindow(this);
	m_ModelessDlg.ShowWindow(SW_SHOWNORMAL);
}


void CChildView::OnDialogCommonDialog()
{
	// TODO: Add your command handler code here
	CColorDialog colorDlg;
	if (colorDlg.DoModal() == IDOK)
	{
		m_color = colorDlg.GetColor();
		Invalidate();
	}
}


void CChildView::OnDialogAdvancedControls()
{
	// TODO: Add your command handler code here
	CAdvancedControlsDlg dlg;
	dlg.DoModal();
}


afx_msg LRESULT CChildView::OnInputReady(WPARAM wParam, LPARAM lParam)
{
	m_x1 = m_ModelessDlg.m_x1;
	m_y1 = m_ModelessDlg.m_y1;
	m_x2 = m_ModelessDlg.m_x2;
	m_y2 = m_ModelessDlg.m_y2;
	Invalidate();
	return 0;
}
