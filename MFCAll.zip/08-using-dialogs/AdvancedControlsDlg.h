#pragma once


// CAdvancedControlsDlg dialog

class CAdvancedControlsDlg : public CDialog
{
	DECLARE_DYNAMIC(CAdvancedControlsDlg)

public:
	CAdvancedControlsDlg(CWnd* pParent = nullptr);   // standard constructor
	virtual ~CAdvancedControlsDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ADVANCEDCONTROLSDLG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CProgressCtrl m_progress1;
	CSliderCtrl m_slider1;
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
};
