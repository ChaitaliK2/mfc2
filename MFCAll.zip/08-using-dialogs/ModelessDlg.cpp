// ModelessDlg.cpp : implementation file
//

#include "pch.h"
#include "ModelessDlg.h"
#include "afxdialogex.h"
#include "resource.h"


// CModelessDlg dialog

IMPLEMENT_DYNAMIC(CModelessDlg, CDialog)

CModelessDlg::CModelessDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_MODELESSDLG, pParent)
	, m_x1(0)
	, m_y1(0)
	, m_x2(0)
	, m_y2(0)
{

}

CModelessDlg::~CModelessDlg()
{
}

void CModelessDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_X1, m_x1);
	DDX_Text(pDX, IDC_EDIT_Y1, m_y1);
	DDX_Text(pDX, IDC_EDIT_X2, m_x2);
	DDX_Text(pDX, IDC_EDIT_Y2, m_y2);
}


BEGIN_MESSAGE_MAP(CModelessDlg, CDialog)
	ON_BN_CLICKED(IDAPPLY, &CModelessDlg::OnClickedIdApply)
	ON_BN_CLICKED(IDCLOSE, &CModelessDlg::OnClickedIdClose)
END_MESSAGE_MAP()


// CModelessDlg message handlers


void CModelessDlg::OnClickedIdApply()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pParentWnd->SendMessage(WM_INPUTREADY);
}


void CModelessDlg::OnClickedIdClose()
{
	// TODO: Add your control notification handler code here
	DestroyWindow();
}
