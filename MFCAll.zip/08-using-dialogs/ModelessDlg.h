#pragma once


// CModelessDlg dialog
#define WM_INPUTREADY  WM_USER+1
class CModelessDlg : public CDialog
{
	DECLARE_DYNAMIC(CModelessDlg)

public:
	CModelessDlg(CWnd* pParent = nullptr);   // standard constructor
	virtual ~CModelessDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MODELESSDLG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnClickedIdApply();
	afx_msg void OnClickedIdClose();
	int m_x1;
	int m_y1;
	int m_x2;
	int m_y2;
};
