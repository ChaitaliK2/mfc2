
// ChildView.h : interface of the CChildView class
//


#pragma once
#include "ModelessDlg.h"

// CChildView window

class CChildView : public CWnd
{
// Construction
public:
	CChildView();

// Attributes
public:

// Operations
public:

// Overrides
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual ~CChildView();

	// Generated message map functions
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnDialogModel();
	afx_msg void OnDialogModeless();
	afx_msg void OnDialogCommonDialog();
	afx_msg void OnDialogAdvancedControls();

private:
	int m_x1;
	int m_y1;
	int m_x2;
	int m_y2;
public:
	CModelessDlg m_ModelessDlg;
	COLORREF m_color;
protected:
	afx_msg LRESULT OnInputReady(WPARAM wParam, LPARAM lParam);
};

