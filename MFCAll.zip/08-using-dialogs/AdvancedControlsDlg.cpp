// CAdvancedControlsDlg.cpp : implementation file
//

#include "pch.h"
#include "AdvancedControlsDlg.h"
#include "afxdialogex.h"
#include "AdvancedControlsDlg.h"
#include "resource.h"

// CAdvancedControlsDlg dialog

IMPLEMENT_DYNAMIC(CAdvancedControlsDlg, CDialog)

CAdvancedControlsDlg::CAdvancedControlsDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_ADVANCEDCONTROLSDLG, pParent)
{

}

CAdvancedControlsDlg::~CAdvancedControlsDlg()
{
}

void CAdvancedControlsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PROGRESS1, m_progress1);
	DDX_Control(pDX, IDC_SLIDER1, m_slider1);
}


BEGIN_MESSAGE_MAP(CAdvancedControlsDlg, CDialog)
	ON_WM_HSCROLL()
END_MESSAGE_MAP()


// CAdvancedControlsDlg message handlers


BOOL CAdvancedControlsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	m_progress1.SetRange(0, 100);
	m_slider1.SetRange(0, 100);
	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}


void CAdvancedControlsDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: Add your message handler code here and/or call default
	int pos = m_slider1.GetPos();
	m_progress1.SetPos(pos);
}
