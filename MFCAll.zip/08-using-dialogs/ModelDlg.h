#pragma once


// CModelDlg dialog

class CModelDlg : public CDialog
{
	DECLARE_DYNAMIC(CModelDlg)

public:
	CModelDlg(int x1,int y1,int x2,int y2,CWnd* pParent = nullptr);   // standard constructor
	virtual ~CModelDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MODALDLG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeEditY2();
	int m_x1;
	int m_y1;
	int m_x2;
	int m_y2;
	afx_msg void OnClickedIdok1();
	afx_msg void OnClickedIdCancel1();
};
