// ModelDlg.cpp : implementation file
//

#include "pch.h"
#include "ModelDlg.h"
#include "afxdialogex.h"
#include "resource.h"

// CModelDlg dialog

IMPLEMENT_DYNAMIC(CModelDlg, CDialog)

CModelDlg::CModelDlg(int x1, int y1, int x2, int y2,CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_MODALDLG, pParent)
	, m_x1(x1)
	, m_y1(y1)
	, m_x2(x2)
	, m_y2(y2)
{

}

CModelDlg::~CModelDlg()
{
}

void CModelDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_X1, m_x1);
	DDV_MinMaxInt(pDX, m_x1, 0, 1000);
	DDX_Text(pDX, IDC_EDIT_Y1, m_y1);
	DDX_Text(pDX, IDC_EDIT_X2, m_x2);
	DDX_Text(pDX, IDC_EDIT_Y2, m_y2);
}


BEGIN_MESSAGE_MAP(CModelDlg, CDialog)
	ON_EN_CHANGE(IDC_EDIT_Y2, &CModelDlg::OnEnChangeEditY2)
	ON_BN_CLICKED(IDOK1, &CModelDlg::OnClickedIdok1)
	ON_BN_CLICKED(IDCANCEL1, &CModelDlg::OnClickedIdCancel1)
END_MESSAGE_MAP()


// CModelDlg message handlers


void CModelDlg::OnEnChangeEditY2()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}


void CModelDlg::OnClickedIdok1()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	EndDialog(IDOK1);
}


void CModelDlg::OnClickedIdCancel1()
{
	// TODO: Add your control notification handler code here
	EndDialog(IDCANCEL1);
}
