
// ChildView.cpp : implementation of the CChildView class
//

#include "pch.h"
#include "framework.h"
#include "PuzzaleGame.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	RandamizedArray();
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_KEYDOWN()
	ON_COMMAND(ID_FILE_NEW, &CChildView::OnFileNew)
END_MESSAGE_MAP()



// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(nullptr, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), nullptr);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CFont SFont;
	CString obj;

	SFont.CreateFont(25, 12, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, 0, 0, _T("Arial"));
	TRACE("%d", ar[2][3]);
	dc.MoveTo(20, 20);
	dc.LineTo(20, 400);
	dc.MoveTo(20, 400);
	dc.LineTo(400, 400);
	dc.MoveTo(400, 400);
	dc.LineTo(400, 20);
	dc.MoveTo(400, 20);
	dc.LineTo(20, 20);
	dc.MoveTo(120, 20);
	dc.LineTo(120, 400);
	dc.MoveTo(220, 20);
	dc.LineTo(20, 20);
	dc.MoveTo(220, 20);
	dc.LineTo(220, 400);
	dc.LineTo(220, 400);
	dc.MoveTo(320, 20);
	dc.LineTo(320, 400);
	dc.MoveTo(20, 120);
	dc.LineTo(400, 120);
	dc.MoveTo(20, 220);
	dc.LineTo(400, 220);
	dc.MoveTo(20, 320);
	dc.LineTo(400, 320);
	CFont* def_font = dc.SelectObject(&SFont);
	a = 20, b = 20, c = 120, d = 120;
	n = 1;
	count = 0;
	for (int i = 0; i < 4; ++i) {
		a = 20;
		c = 120;
		for (int j = 0; j < 4; ++j) {
			if (ar[i][j] == n)
				count += 1;
			if (ar[i][j] == 0)
			{
				r1 = i;
				c2 = j;
				dc.DrawText(TEXT(" "), CRect(a, b, c, d), DT_VCENTER | DT_CENTER | DT_SINGLELINE);
				//TRACE("\n%d,%d\n", i,j);
			}
			else
			{
				//TRACE("%d\n", ar[i][j]);
				obj.Format(TEXT("%d"), ar[i][j]);
				dc.DrawText(obj, CRect(a, b, c, d), DT_VCENTER | DT_CENTER | DT_SINGLELINE);
			}
			a += 100;
			c += 100;
			n += 1;
		}
		b += 100;
		d += 100;
	}
	dc.SelectObject(def_font);
}



void CChildView::OnFileNew()
{
	// TODO: Add your command handler code here
	RandamizedArray();
	Invalidate();
}

void CChildView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	switch (nChar)
	{
	case VK_UP:
		OnUpKeyDown();
		break;
	case VK_DOWN:
		OnDownKeyDown();
		break;
	case VK_LEFT:
		OnLeftKeyDown();
		break;
	case VK_RIGHT:
		OnRightKeyDown();
		break;
	default:
		break;
	}
}
void CChildView::OnLeftKeyDown()
{
	if (c2 < 3) {

		//swap(ar[r1][c2], ar[r1][c2 +1]);
		temp = ar[r1][c2];
		ar[r1][c2] = ar[r1][c2 + 1];
		ar[r1][c2 + 1] = 0;
		Invalidate();
	}


}
void CChildView::OnRightKeyDown()
{
	if (c2 > 0) {

		temp = ar[r1][c2];
		ar[r1][c2] = ar[r1][c2 - 1];
		ar[r1][c2 - 1] = 0;
		Invalidate();
	}

}
void CChildView::OnUpKeyDown()
{
	if (r1 < 3) {
		temp = ar[r1][c2];
		ar[r1][c2] = ar[r1 + 1][c2];
		ar[r1 + 1][c2] = 0;
		Invalidate();
	}

}
void CChildView::OnDownKeyDown()
{
	if (r1 > 0) {
		//swap(ar[r1][c2], ar[r1-1][c2]);
		temp = ar[r1][c2];
		ar[r1][c2] = ar[r1 - 1][c2];
		ar[r1 - 1][c2] = 0;
		Invalidate();
	}

}
void CChildView::RandamizedArray()
{
	// TODO: Add your implementation code here.
	for (int h = 0; h < 4; h++) {
		for (int l = 0; l < 4; l++) {
			ar[h][l] = -1;
		}
	}
	int r, c;
	for (int k = 0; k < 16; k++)
	{
		while (TRUE) {
			r = rand() % 4;
			TRACE("\n%d\n", r);
			c = rand() % 4;
			if (ar[r][c] == -1) {
				ar[r][c] = k;
				break;
			}
		}

	}
}
