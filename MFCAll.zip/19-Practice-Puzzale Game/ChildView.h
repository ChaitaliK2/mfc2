
// ChildView.h : interface of the CChildView class
//


#pragma once


// CChildView window

class CChildView : public CWnd
{
// Construction
public:
	CChildView();

// Attributes
public:

// Operations
public:

// Overrides
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual ~CChildView();

	// Generated message map functions
protected:
	afx_msg void OnPaint();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnFileNew();
	void OnLeftKeyDown();
	void OnRightKeyDown();
	void OnUpKeyDown();
	void OnDownKeyDown();
	void RandamizedArray();


private:
	int r1, c2;
	int count, n;
	int temp = 0;
	int ar[4][4] = {};
	int a, b, c, d;

};

