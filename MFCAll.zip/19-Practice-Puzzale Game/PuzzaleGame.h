
// 19-Practice-Puzzale Game.h : main header file for the 19-Practice-Puzzale Game application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'pch.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CPuzzaleGameApp:
// See 19-Practice-Puzzale Game.cpp for the implementation of this class
//

class CPuzzaleGameApp : public CWinApp
{
public:
	CPuzzaleGameApp() noexcept;


// Overrides
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

// Implementation

public:
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CPuzzaleGameApp theApp;
