
// 15-Practice-1.h : main header file for the 15-Practice-1 application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'pch.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CMy15Practice1App:
// See 15-Practice-1.cpp for the implementation of this class
//

class CMy15Practice1App : public CWinApp
{
public:
	CMy15Practice1App() noexcept;


// Overrides
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

// Implementation

public:
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CMy15Practice1App theApp;
