#pragma once


// CTimerDlg dialog
#define TIMERCOUNT 1

class CTimerDlg : public CDialog
{
	DECLARE_DYNAMIC(CTimerDlg)

public:
	CTimerDlg(CWnd* pParent = nullptr);   // standard constructor
	virtual ~CTimerDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CTIMERDLG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedStart();
	afx_msg void OnClickedIdclose();
	afx_msg void OnTimer(UINT_PTR nIDEvent);

private:
	CEdit Edit_number;
	int number;
	CString str;
};
