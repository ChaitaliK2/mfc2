// TimerDlg.cpp : implementation file

#include "pch.h"
#include "TimerApp.h"
#include "TimerDlg.h"
#include "afxdialogex.h"
#include "resource.h"

// CTimerDlg dialog
int flag = 0;
IMPLEMENT_DYNAMIC(CTimerDlg, CDialog)

CTimerDlg::CTimerDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_CTIMERDLG, pParent)
{
	number = 0;
	str = _T("");
}

CTimerDlg::~CTimerDlg()
{
}

void CTimerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CTimerDlg, CDialog)
	ON_BN_CLICKED(IDSTART, &CTimerDlg::OnBnClickedStart)
	ON_BN_CLICKED(IDCLOSE, &CTimerDlg::OnClickedIdclose)
	ON_WM_TIMER()
END_MESSAGE_MAP()

// CTimerDlg message handlers

void CTimerDlg::OnBnClickedStart()
{
	// TODO: Add your control notification handler code 
	SetTimer(TIMERCOUNT, 100, NULL);
	if (flag == 1)
	{
		number = 0;
	}
}

void CTimerDlg::OnClickedIdclose()
{
	// TODO: Add your control notification handler code here
	EndDialog(IDCLOSE);
}

void CTimerDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: Add your message handler code here and/or call default

	if (nIDEvent == TIMERCOUNT)
	{
		if (number < 100)
		{
			number++;
			CString str;
			str.Format(_T("%d"), number);
			GetDlgItem(IDC_EDIT1)->SetWindowTextW(str);
		}
		else
		{
			KillTimer(TIMERCOUNT);
		}
		if (number == 99)
		{
				flag = 1;
		}
	}
	

	CDialog::OnTimer(nIDEvent);
}
