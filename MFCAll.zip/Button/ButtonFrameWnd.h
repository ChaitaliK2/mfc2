#pragma once


// CButtonFrameWnd frame

class CButtonFrameWnd : public CFrameWnd
{
	DECLARE_DYNCREATE(CButtonFrameWnd)
public:
	CButtonFrameWnd();           // protected constructor used by dynamic creation
	virtual ~CButtonFrameWnd();

protected:
	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnClickedButton();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);

private:
	CButton m_btn;
	bool m_redCol{FALSE};
public:
	afx_msg void OnPaint();

private:
	int button;
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
};


