// ButtonFrameWnd.cpp : implementation file
#include "pch.h"
#include "ButtonApp.h"
#include "ButtonFrameWnd.h"
#include "resource.h"
// CButtonFrameWnd

IMPLEMENT_DYNCREATE(CButtonFrameWnd, CFrameWnd)

CButtonFrameWnd::CButtonFrameWnd()
{}

CButtonFrameWnd::~CButtonFrameWnd()
{}

BEGIN_MESSAGE_MAP(CButtonFrameWnd, CFrameWnd)
	ON_COMMAND(ID_BUTTON, &CButtonFrameWnd::OnClickedButton)
	ON_WM_CREATE()
	ON_WM_PAINT()
END_MESSAGE_MAP()

// CButtonFrameWnd message handlers
void CButtonFrameWnd::OnClickedButton()
{
	// TODO: Add your command handler code here
	m_redCol = TRUE;
	Invalidate(TRUE);
}

int CButtonFrameWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	// TODO:  Add your specialized creation code here
	m_btn.Create(TEXT("Show"), WS_BORDER | WS_CHILD | WS_VISIBLE, CRect(310, 300, 510, 340), this, ID_BUTTON);
	return 0;
}

void CButtonFrameWnd::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	int r, g, b;
	/*r = rand() % 255;
	g = rand() % 255;
	b = rand() % 255;*/
	CBrush brush;
	CRect rectClient;
	GetClientRect(&rectClient);
	brush.CreateSolidBrush(RGB(m_redCol ? 255 : 0, 0, 0));
	dc.FillRect(&rectClient,&brush);
}

BOOL CButtonFrameWnd::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	// TODO: Add your specialized code here and/or call the base class
	cs.cx = 630;
	cs.cy = 440;
	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~(WS_MAXIMIZEBOX | WS_THICKFRAME);
	return TRUE;
}
