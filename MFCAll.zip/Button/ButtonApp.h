#pragma once



// CButtonApp

class CButtonApp : public CWinApp
{
	DECLARE_DYNCREATE(CButtonApp)

public:
	CButtonApp();           // protected constructor used by dynamic creation
	virtual ~CButtonApp();

public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

protected:
	DECLARE_MESSAGE_MAP()
};


