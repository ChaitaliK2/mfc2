// ButtonApp.cpp : implementation file
//

#include "pch.h"
#include "ButtonApp.h"
#include "ButtonFrameWnd.h"
#include "resource.h"

// CButtonApp
CButtonApp theButtonApp;
IMPLEMENT_DYNCREATE(CButtonApp, CWinApp)

CButtonApp::CButtonApp()
{
}

CButtonApp::~CButtonApp()
{
}

BOOL CButtonApp::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	CButtonFrameWnd* pFrame = new CButtonFrameWnd();
	pFrame->Create(NULL, TEXT("Multithreading demo"));
	pFrame->ShowWindow(m_nCmdShow);
	m_pMainWnd = pFrame;
	return TRUE;
}

int CButtonApp::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinApp::ExitInstance();
}

BEGIN_MESSAGE_MAP(CButtonApp, CWinApp)
END_MESSAGE_MAP()


// CButtonApp message handlers
