#pragma once


// CErrorLookupWnd frame

class CErrorLookupWnd : public CFrameWnd
{
	DECLARE_DYNCREATE(CErrorLookupWnd)
public:
	CErrorLookupWnd();           // protected constructor used by dynamic creation
	virtual ~CErrorLookupWnd();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnToolsErrorLookup();
};


