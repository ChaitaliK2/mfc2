#pragma once



// CErrorLookupApp

class CErrorLookupApp : public CWinApp
{
	DECLARE_DYNCREATE(CErrorLookupApp)

public:
	CErrorLookupApp();           // protected constructor used by dynamic creation
	virtual ~CErrorLookupApp();

public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

protected:
	DECLARE_MESSAGE_MAP()
};


