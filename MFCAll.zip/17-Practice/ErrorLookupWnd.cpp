// ErrorLookupWnd.cpp : implementation file
//

#include "pch.h"
#include "ErrorLookupWnd.h"
#include "ErrorLookupDlg.h"
#include "resource.h"

// CErrorLookupWnd

IMPLEMENT_DYNCREATE(CErrorLookupWnd, CFrameWnd)

CErrorLookupWnd::CErrorLookupWnd()
{

}

CErrorLookupWnd::~CErrorLookupWnd()
{
}


BEGIN_MESSAGE_MAP(CErrorLookupWnd, CFrameWnd)
	ON_COMMAND(ID_TOOLS_ERRORLOOKUP, &CErrorLookupWnd::OnToolsErrorLookup)
END_MESSAGE_MAP()


// CErrorLookupWnd message handlers


void CErrorLookupWnd::OnToolsErrorLookup()
{
	// TODO: Add your command handler code here
	CErrorLookupDlg modelDlg;
	modelDlg.DoModal();
}
