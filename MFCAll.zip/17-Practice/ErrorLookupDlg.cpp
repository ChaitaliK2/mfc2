// ErrorLookupDlg.cpp : implementation file
//

#include "pch.h"
#include "ErrorLookupDlg.h"
#include "afxdialogex.h"
#include "resource.h"

// CErrorLookupDlg dialog

IMPLEMENT_DYNAMIC(CErrorLookupDlg, CDialog)

CErrorLookupDlg::CErrorLookupDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_ERRORLOOKUPDLG, pParent)
	, m_errorCode(_T(""))
	, m_errorDesc(_T(""))
{

}

CErrorLookupDlg::~CErrorLookupDlg()
{
}

void CErrorLookupDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_errorCode);
	DDX_Text(pDX, IDC_STATICERRORMSG, m_errorDesc);
}


BEGIN_MESSAGE_MAP(CErrorLookupDlg, CDialog)
	ON_BN_CLICKED(IDCLOSE, &CErrorLookupDlg::OnClickedIdClose)
	ON_BN_CLICKED(IDLOOKUP, &CErrorLookupDlg::OnClickedIdLookup)
END_MESSAGE_MAP()


// CErrorLookupDlg message handlers


void CErrorLookupDlg::OnClickedIdClose()
{
	// TODO: Add your control notification handler code here
	EndDialog(IDCLOSE);
}


void CErrorLookupDlg::OnClickedIdLookup()
{
	// TODO: Add your control notification handler code here
	UpdateData();

	CStdioFile cfile;
	cfile.Open(_T("ErrorList.txt"), CFile::modeRead);

	BOOL found = FALSE;
	CString line;
	while (cfile.ReadString(line))
	{
		int curpos = 0;
		CString errorCode = line.Tokenize(TEXT("\t"), curpos);
		CString errorDesc = line.Tokenize(TEXT("\t"), curpos);
		// check errorCode with m_errorCode
		if (m_errorCode == errorCode)
		{
			m_errorDesc = errorDesc;
			UpdateData(FALSE);
			found = TRUE;
		}
		
	}
	cfile.Close();

	if (!found)
	{
		MessageBox(TEXT("Message not found"),TEXT("Error Lookup"),MB_OK | MB_ICONEXCLAMATION);
	}
}
