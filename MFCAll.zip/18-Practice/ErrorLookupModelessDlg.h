#pragma once


// CErrorLookupModelessDlg dialog

class CErrorLookupModelessDlg : public CDialog
{
	DECLARE_DYNAMIC(CErrorLookupModelessDlg)

public:
	CErrorLookupModelessDlg(CWnd* pParent = nullptr);   // standard constructor
	virtual ~CErrorLookupModelessDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ERRORLOOKUPMODELESSDLG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnClickedIdClose();
	afx_msg void OnClickedIdLookup();
	CString m_errorCode;
	CString m_errorDesc;
};
