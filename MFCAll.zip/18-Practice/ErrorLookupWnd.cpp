// ErrorLookupWnd.cpp : implementation file
//

#include "pch.h"
#include "ErrorLookupWnd.h"
#include "ErrorLookupModelessDlg.h"
#include "resource.h"

// CErrorLookupWnd

IMPLEMENT_DYNCREATE(CErrorLookupWnd, CFrameWnd)

CErrorLookupWnd::CErrorLookupWnd()
{

}

CErrorLookupWnd::~CErrorLookupWnd()
{
}


BEGIN_MESSAGE_MAP(CErrorLookupWnd, CFrameWnd)
	ON_COMMAND(ID_TOOLS_ERRORLOOKUP, &CErrorLookupWnd::OnToolsErrorLookup)
END_MESSAGE_MAP()


// CErrorLookupWnd message handlers


void CErrorLookupWnd::OnToolsErrorLookup()
{
	// TODO: Add your command handler code here
	if (m_ModelessDlg.GetSafeHwnd() == NULL)
		m_ModelessDlg.Create(IDD_ERRORLOOKUPMODELESSDLG);
	m_ModelessDlg.CenterWindow(this);
	m_ModelessDlg.ShowWindow(SW_SHOWNORMAL);
}
