// ErrorLookupApp.cpp : implementation file
//

#include "pch.h"
#include "ErrorLookupApp.h"
#include "ErrorLookupWnd.h"
#include "resource.h"
// CErrorLookupApp

CErrorLookupApp theApp;
IMPLEMENT_DYNCREATE(CErrorLookupApp, CWinApp)

CErrorLookupApp::CErrorLookupApp()
{
}

CErrorLookupApp::~CErrorLookupApp()
{
}

BOOL CErrorLookupApp::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	CWinApp::InitInstance();

	EnableTaskbarInteraction(FALSE);
	CFrameWnd* pFrame = new CErrorLookupWnd;
	if (!pFrame)
		return FALSE;
	m_pMainWnd = pFrame;
	// create and load the frame with its resources
	pFrame->LoadFrame(IDR_APP_RES,
		WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, nullptr,
		nullptr);
	pFrame->ShowWindow(SW_SHOW);
	pFrame->UpdateWindow();
	return TRUE;
}

int CErrorLookupApp::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinApp::ExitInstance();
}

BEGIN_MESSAGE_MAP(CErrorLookupApp, CWinApp)
END_MESSAGE_MAP()


// CErrorLookupApp message handlers
