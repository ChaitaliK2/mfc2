// ErrorLookupModelessDlg.cpp : implementation file
//

#include "pch.h"
#include "ErrorLookupModelessDlg.h"
#include "afxdialogex.h"
#include "ErrorLookupModelessDlg.h"
#include "resource.h"

// CErrorLookupModelessDlg dialog

IMPLEMENT_DYNAMIC(CErrorLookupModelessDlg, CDialog)

CErrorLookupModelessDlg::CErrorLookupModelessDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_ERRORLOOKUPMODELESSDLG, pParent)
	, m_errorCode(_T(""))
	, m_errorDesc(_T(""))
{

}

CErrorLookupModelessDlg::~CErrorLookupModelessDlg()
{
}

void CErrorLookupModelessDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_errorCode);
	DDX_Text(pDX, IDC_STATICERRORMSG, m_errorDesc);
}


BEGIN_MESSAGE_MAP(CErrorLookupModelessDlg, CDialog)
	ON_BN_CLICKED(IDCLOSE, &CErrorLookupModelessDlg::OnClickedIdClose)
	ON_BN_CLICKED(IDLOOKUP, &CErrorLookupModelessDlg::OnClickedIdLookup)
END_MESSAGE_MAP()


// CErrorLookupModelessDlg message handlers
void CErrorLookupModelessDlg::OnClickedIdClose()
{
	// TODO: Add your control notification handler code here
	DestroyWindow();
}


void CErrorLookupModelessDlg::OnClickedIdLookup()
{
	// TODO: Add your control notification handler code here
	UpdateData();

	CStdioFile cfile;
	cfile.Open(_T("ErrorList.txt"), CFile::modeRead);

	BOOL found = FALSE;
	CString line;
	while (cfile.ReadString(line))
	{
		int curpos = 0;
		CString errorCode = line.Tokenize(TEXT("\t"), curpos);
		CString errorDesc = line.Tokenize(TEXT("\t"), curpos);
		// check errorCode with m_errorCode
		if (m_errorCode == errorCode)
		{
			m_errorDesc = errorDesc;
			UpdateData(FALSE);
			found = TRUE;
		}

	}
	cfile.Close();

	if (!found)
	{
		MessageBox(TEXT("Message not found"), TEXT("Error Lookup"), MB_OK | MB_ICONEXCLAMATION);
	}
}
