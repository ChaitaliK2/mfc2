//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by 18-Practice.rc
//
#define IDD_ERRORLOOKUPMODELESSDLG      101
#define IDR_APP_RES                     103
#define IDC_EDIT1                       1001
#define IDC_STATIC1                     1003
#define IDC_STATICERRORMSG              1004
#define IDLOOKUP                        1005
#define ID_TOOLS_ERRORLOOKUP            40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
