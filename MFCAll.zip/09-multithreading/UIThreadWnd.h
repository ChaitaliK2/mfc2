#pragma once


// CUIThreadWnd frame

class CUIThreadWnd : public CFrameWnd
{
	DECLARE_DYNCREATE(CUIThreadWnd)
public:
	CUIThreadWnd();           
	virtual ~CUIThreadWnd();

protected:
	DECLARE_MESSAGE_MAP()
};


