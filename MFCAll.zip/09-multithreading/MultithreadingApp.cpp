// MultithreadingApp.cpp : implementation file
//

#include "pch.h"
#include "MultithreadingApp.h"
#include "MainFrame.h"

// CMultithreadingApp

CMultithreadingApp theApp;
IMPLEMENT_DYNCREATE(CMultithreadingApp, CWinApp)

CMultithreadingApp::CMultithreadingApp(){}

CMultithreadingApp::~CMultithreadingApp(){}

BOOL CMultithreadingApp::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	CMainFrame* pFrame = new CMainFrame();
	pFrame->Create(NULL, TEXT("Multithreading demo"));
	pFrame->ShowWindow(m_nCmdShow);
	m_pMainWnd = pFrame;
	return TRUE;
}

int CMultithreadingApp::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinApp::ExitInstance();
}

BEGIN_MESSAGE_MAP(CMultithreadingApp, CWinApp)
END_MESSAGE_MAP()


// CMultithreadingApp message handlers
