#pragma once



// CMultithreadingApp

class CMultithreadingApp : public CWinApp
{
	DECLARE_DYNCREATE(CMultithreadingApp)

public:
	CMultithreadingApp();           // protected constructor used by dynamic creation
	virtual ~CMultithreadingApp();

public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

protected:
	DECLARE_MESSAGE_MAP()
};


