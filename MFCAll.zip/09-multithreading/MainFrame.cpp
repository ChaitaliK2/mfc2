// MainFrame.cpp : implementation file
//

#include "pch.h"
#include "MainFrame.h"
#include "resource.h"
#include "UIThread.h"

int CMainFrame::m_i = 0;
CMutex CMainFrame::m_mutex(FALSE,TEXT("Mutex1"));
CCriticalSection CMainFrame::m_cs;
CSemaphore CMainFrame::m_semaphore(3,3,TEXT("Semaphore"));
CEvent CMainFrame::m_event(TRUE,TRUE,TEXT("Myevent"));
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

CMainFrame::CMainFrame() {}

CMainFrame::~CMainFrame(){}


BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_BN_CLICKED(ID_BUTTON_CLEAR, &CMainFrame::OnClickedButtonClear)
	ON_BN_CLICKED(ID_BUTTON_MULTITHREADING, &CMainFrame::OnClickedButtonMultithreading)
	ON_BN_CLICKED(ID_BUTTON_CS, &CMainFrame::OnClickedButtonCS)
	ON_BN_CLICKED(ID_BUTTON_MUTEX, &CMainFrame::OnClickedButtonMutex)
	ON_BN_CLICKED(ID_BUTTON_SEMAPHORE, &CMainFrame::OnClickedButtonSemaphore)
	ON_BN_CLICKED(ID_BUTTON_EVENT, &CMainFrame::OnClickedButtonEvent)
	ON_BN_CLICKED(ID_BUTTON_UITHREAD, &CMainFrame::OnClickedButtonUIThread)
END_MESSAGE_MAP()


// CMainFrame message handlers


BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;
	// TODO: Add your specialized code here and/or call the base class.
	cs.cx = 630;
	cs.cy = 440;
	cs.style &= ~(WS_MAXIMIZEBOX | WS_THICKFRAME);
	return TRUE;
}


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  Add your specialized creation code here
	m_lb1.Create(WS_VSCROLL |WS_BORDER | WS_VISIBLE,CRect(20,10,220,350),this,ID_LISTBOX1);
	m_lb2.Create(WS_VSCROLL | WS_BORDER | WS_VISIBLE, CRect(240, 10, 440, 350), this, ID_LISTBOX2);
	m_btnClear.Create(TEXT("Clear"), WS_BORDER | WS_CHILD | WS_VISIBLE, CRect(460, 10, 590, 40), this, ID_BUTTON_CLEAR);
	m_btnMultithreading.Create(TEXT("Multithreading"), WS_BORDER | WS_CHILD | WS_VISIBLE, CRect(460, 60, 590, 90), this, ID_BUTTON_MULTITHREADING);
	m_btnCS.Create(TEXT("CS"), WS_BORDER | WS_CHILD | WS_VISIBLE, CRect(460, 110, 590, 140), this, ID_BUTTON_CS);
	m_btnMutex.Create(TEXT("Mutex"), WS_BORDER | WS_CHILD | WS_VISIBLE, CRect(460, 160, 590, 190), this, ID_BUTTON_MUTEX);
	m_btnSemaphore.Create(TEXT("Semaphore"), WS_BORDER | WS_CHILD | WS_VISIBLE, CRect(460, 210, 590, 240), this, ID_BUTTON_SEMAPHORE);
	m_btnEvent.Create(TEXT("Event"), WS_BORDER | WS_CHILD | WS_VISIBLE, CRect(460, 260, 590, 290), this, ID_BUTTON_EVENT);
	m_btnUIThread.Create(TEXT("UI Thread"), WS_BORDER | WS_CHILD | WS_VISIBLE, CRect(460, 310, 590, 340), this, ID_BUTTON_UITHREAD);
	return 0;
}


void CMainFrame::OnClickedButtonClear()
{
	// TODO: Add your command handler code here
	m_lb1.ResetContent();
	m_lb2.ResetContent();
}



void CMainFrame::OnClickedButtonMultithreading()
{
	// TODO: Add your command handler code here
	AfxBeginThread(&ThreadProc1, static_cast<LPVOID>(m_lb1.m_hWnd));
	AfxBeginThread(&ThreadProc2, static_cast<LPVOID>(m_lb2.m_hWnd));

}


UINT CMainFrame::ThreadProc1(LPVOID lpParameter)
{
	CListBox lb;
	CString message;
	lb.Attach(static_cast<HWND>(lpParameter));
	for (int counter = 0; counter < 50; counter++) {
		message.Format(TEXT("From ThreadProc1: %d"), counter);
		lb.InsertString(0, message);
		Sleep(50);
	}
	lb.Detach();
	return 0;
}
UINT CMainFrame::ThreadProc2(LPVOID lpParameter)
{
	CListBox lb;
	CString message;
	lb.Attach(static_cast<HWND>(lpParameter));
	for (int counter = 0; counter < 50; counter++) {
		message.Format(TEXT("From ThreadProc2: %d"), counter);
		lb.InsertString(0, message);
		Sleep(50);
	}
	lb.Detach();
	return 0;
}


void CMainFrame::OnClickedButtonCS()
{
	// TODO: Add your command handler code here
	AfxBeginThread(&CSThreadProc, static_cast<LPVOID>(m_lb1.m_hWnd));
	AfxBeginThread(&CSThreadProc, static_cast<LPVOID>(m_lb2.m_hWnd));
}

UINT CMainFrame::CSThreadProc(LPVOID lpParameter)
{
	CListBox lb;
	CString message;
	lb.Attach(static_cast<HWND>(lpParameter));
	for (int counter = 0; counter < 50; counter++) {
		m_cs.Lock();
		message.Format(TEXT("Before increment i: %d"), m_i);
		lb.InsertString(0, message);
		m_i++;
		Sleep(50);
		message.Format(TEXT("After increment: %d"), m_i);
		lb.InsertString(0, message);
		m_cs.Unlock();
		Sleep(50);
	}
	lb.Detach();
	return 0;
}

void CMainFrame::OnClickedButtonMutex()
{
	// TODO: Add your command handler code here
	AfxBeginThread(&MutexThreadProc, static_cast<LPVOID>(m_lb1.m_hWnd));
	AfxBeginThread(&MutexThreadProc, static_cast<LPVOID>(m_lb2.m_hWnd));

}

UINT CMainFrame::MutexThreadProc(LPVOID lpParameter)
{
	CListBox lb;
	CString message;
	lb.Attach(static_cast<HWND>(lpParameter));
	CSingleLock csl(&m_mutex);
	csl.Lock();
	for(int counter = 0; counter < 50; counter++) {
		message.Format(TEXT("Before increment i: %d"), m_i);
		lb.InsertString(0, message);
		m_i++;
		Sleep(50);
		message.Format(TEXT("After increment: %d"), m_i);
		lb.InsertString(0, message);
		Sleep(50);
	}
	csl.Unlock();
	lb.Detach();
	return 0;
}

void CMainFrame::OnClickedButtonSemaphore()
{
	// TODO: Add your command handler code here
	AfxBeginThread(&SemaphoreThreadProc, static_cast<LPVOID>(m_lb1.m_hWnd));
	AfxBeginThread(&SemaphoreThreadProc, static_cast<LPVOID>(m_lb2.m_hWnd));
}

UINT CMainFrame::SemaphoreThreadProc(LPVOID lpParameter)
{
	CListBox lb;
	CString message;
	lb.Attach(static_cast<HWND>(lpParameter));
	CSingleLock csl(&m_semaphore);
	csl.Lock();
	for (int counter = 0; counter < 50; counter++) {
		message.Format(TEXT("Before increment i: %d"), m_i);
		lb.InsertString(0, message);
		m_i++;
		Sleep(50);
		message.Format(TEXT("After increment: %d"), m_i);
		lb.InsertString(0, message);
		Sleep(50);
	}
	csl.Unlock();
	lb.Detach();

	return 0;
}

void CMainFrame::OnClickedButtonEvent()
{
	// TODO: Add your command handler code here
	AfxBeginThread(&EventThreadProc, static_cast<LPVOID>(m_lb1.m_hWnd));
	AfxBeginThread(&EventThreadProc, static_cast<LPVOID>(m_lb2.m_hWnd));
}

UINT CMainFrame::EventThreadProc(LPVOID lpParameter)
{
	CListBox lb;
	CString message;
	lb.Attach(static_cast<HWND>(lpParameter));
	//CSingleLock csl(&m_event);
	m_event.Lock();
	m_event.ResetEvent();
	for (int counter = 0; counter < 50; counter++) {
		message.Format(TEXT("Before increment i: %d"), m_i);
		lb.InsertString(0, message);
		m_i++;
		Sleep(50);
		message.Format(TEXT("After increment: %d"), m_i);
		lb.InsertString(0, message);
		Sleep(50);
	}
	m_event.Unlock();
	m_event.SetEvent();
	lb.Detach();

	return 0;
}

void CMainFrame::OnClickedButtonUIThread()
{
	// TODO: Add your command handler code here
	AfxBeginThread(RUNTIME_CLASS(CUIThread));
}
