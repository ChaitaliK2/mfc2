// UIThreadWnd.cpp : implementation file
//

#include "pch.h"
#include "UIThreadWnd.h"


// CUIThreadWnd

IMPLEMENT_DYNCREATE(CUIThreadWnd, CFrameWnd)

CUIThreadWnd::CUIThreadWnd()
{

}

CUIThreadWnd::~CUIThreadWnd()
{
}


BEGIN_MESSAGE_MAP(CUIThreadWnd, CFrameWnd)
END_MESSAGE_MAP()


// CUIThreadWnd message handlers
