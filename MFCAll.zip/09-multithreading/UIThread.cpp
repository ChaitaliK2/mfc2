// UIThread.cpp : implementation file
//

#include "pch.h"
#include "UIThread.h"
#include "UIThreadWnd.h"

// CUIThread

IMPLEMENT_DYNCREATE(CUIThread, CWinThread)

CUIThread::CUIThread(){}

CUIThread::~CUIThread(){}

BOOL CUIThread::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	CUIThreadWnd* pWnd = new CUIThreadWnd();
	pWnd->Create(NULL, TEXT("UIThread Window"));
	pWnd->ShowWindow(SW_SHOWNORMAL);
	m_pMainWnd = pWnd;
	return TRUE;
}

int CUIThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CUIThread, CWinThread)
END_MESSAGE_MAP()


// CUIThread message handlers
