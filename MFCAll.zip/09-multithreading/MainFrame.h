#pragma once


// CMainFrame frame

class CMainFrame : public CFrameWnd
{
	DECLARE_DYNCREATE(CMainFrame)
public:
	CMainFrame();           // protected constructor used by dynamic creation
	virtual ~CMainFrame();

protected:
	DECLARE_MESSAGE_MAP()
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
private:
	CListBox m_lb1;
	CListBox m_lb2;
	CButton m_btnClear;
	CButton m_btnMultithreading;
	CButton m_btnCS;
	CButton m_btnMutex;
	CButton m_btnSemaphore;
	CButton m_btnEvent;
	CButton m_btnUIThread;
private:
	static UINT ThreadProc1(LPVOID lpParameter);
	static UINT ThreadProc2(LPVOID lpParameter);
	static UINT CSThreadProc(LPVOID lpParameter);
	static UINT MutexThreadProc(LPVOID lpParameter);
	static UINT SemaphoreThreadProc(LPVOID lpParameter);
	static UINT EventThreadProc(LPVOID lpParameter);


public:
	afx_msg void OnClickedButtonClear();
	afx_msg void OnClickedButtonMultithreading();
	afx_msg void OnClickedButtonCS();

private:
	static int m_i;
	static CCriticalSection m_cs;
	static CMutex m_mutex;
	static CSemaphore m_semaphore;
	static CEvent m_event;

public:
	afx_msg void OnClickedButtonMutex();
	afx_msg void OnClickedButtonSemaphore();
	afx_msg void OnClickedButtonEvent();
	afx_msg void OnClickedButtonUIThread();
};


