// CanvasView.cpp : implementation file
//

#include "pch.h"
#include "CanvasView.h"
#include "CanvasDoc.h"
#include "CanvasWnd.h"

// CCanvasView

IMPLEMENT_DYNCREATE(CCanvasView, CView)

CCanvasView::CCanvasView()
{

}

CCanvasView::~CCanvasView()
{
}

BEGIN_MESSAGE_MAP(CCanvasView, CView)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
END_MESSAGE_MAP()


// CCanvasView drawing

void CCanvasView::OnDraw(CDC* pDC)
{
	CCanvasDoc* pDoc = dynamic_cast<CCanvasDoc*>(GetDocument());

	// TODO: add draw code here
	pDC->Rectangle(pDoc->m_p1.x, pDoc->m_p1.y, pDoc->m_p2.x, pDoc->m_p2.y);
}


// CCanvasView diagnostics

#ifdef _DEBUG
void CCanvasView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CCanvasView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
#endif //_DEBUG


// CCanvasView message handlers


void CCanvasView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	dynamic_cast<CCanvasDoc*>(GetDocument())->m_p1 = point;
}

void CCanvasView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	dynamic_cast<CCanvasDoc*>(GetDocument())->m_p2 = point;
	dynamic_cast<CCanvasDoc*>(GetDocument())->UpdateAllViews(NULL);

}


void CCanvasView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	CString buffer;
	buffer.Format(TEXT("x=%d,y=%d"), point.x, point.y);
	static_cast<CCanvasWnd*>(GetParentFrame())->m_statusBar.SetPaneText(3, buffer);
}
