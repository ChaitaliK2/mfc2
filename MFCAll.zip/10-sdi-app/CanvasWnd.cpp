// CanvasWnd.cpp : implementation file
//

#include "pch.h"
#include "CanvasWnd.h"
#include "CanvasView.h"
#include "CanvasView2.h"
#include "resource.h"
// CCanvasWnd

IMPLEMENT_DYNCREATE(CCanvasWnd, CFrameWnd)

CCanvasWnd::CCanvasWnd()
{

}

CCanvasWnd::~CCanvasWnd()
{
}


BEGIN_MESSAGE_MAP(CCanvasWnd, CFrameWnd)
	ON_WM_CREATE()
END_MESSAGE_MAP()


// CCanvasWnd message handlers


BOOL CCanvasWnd::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	// TODO: Add your specialized code here and/or call the base class
	CRect rect;
	GetClientRect(&rect);
	m_splitterWnd.CreateStatic(this, 2, 1);
	m_splitterWnd.CreateView(0, 0, RUNTIME_CLASS(CCanvasView), CSize(0, rect.bottom / 2), pContext);
	m_splitterWnd.CreateView(1, 0, RUNTIME_CLASS(CCanvasView2), CSize(0, rect.bottom / 2), pContext);

	return TRUE;
}


int CCanvasWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  Add your specialized creation code here
	m_toolBar.CreateEx(this,TBSTYLE_FLAT,WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	m_toolBar.LoadToolBar(IDR_TOOLBAR1);
	m_toolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_toolBar);
	m_toolBar.SetWindowText(TEXT("Standard"));


	m_statusBar.Create(this);
	static const UINT indicators[] = {ID_SEPARATOR,ID_INDICATOR_CAPS,ID_INDICATOR_NUM,ID_INDICATOR_XY};
	m_statusBar.SetIndicators(indicators, sizeof(indicators) / sizeof(UINT));
	m_statusBar.SetPaneInfo(3, ID_INDICATOR_XY,SBPS_NORMAL,100);
	return 0;
}
