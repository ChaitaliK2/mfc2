// CanvasView2.cpp : implementation file
//

#include "pch.h"
#include "CanvasView2.h"
#include "CanvasDoc.h"
#include "CanvasWnd.h"

// CCanvasView2

IMPLEMENT_DYNCREATE(CCanvasView2, CView)

CCanvasView2::CCanvasView2()
{

}

CCanvasView2::~CCanvasView2()
{
}

BEGIN_MESSAGE_MAP(CCanvasView2, CView)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()


// CCanvasView2 drawing

void CCanvasView2::OnDraw(CDC* pDC)
{
	CCanvasDoc* pDoc = dynamic_cast<CCanvasDoc*>(GetDocument());

	// TODO: add draw code here
	pDC->Ellipse(pDoc->m_p1.x, pDoc->m_p1.y, pDoc->m_p2.x, pDoc->m_p2.y);
	// TODO: add draw code here
}


// CCanvasView2 diagnostics

#ifdef _DEBUG
void CCanvasView2::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CCanvasView2::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
#endif //_DEBUG


// CCanvasView2 message handlers


void CCanvasView2::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	dynamic_cast<CCanvasDoc*>(GetDocument())->m_p1 = point;
}


void CCanvasView2::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	dynamic_cast<CCanvasDoc*>(GetDocument())->m_p2 = point;
	dynamic_cast<CCanvasDoc*>(GetDocument())->UpdateAllViews(NULL);
}

//void CCanvasView2::OnMouseMove(UINT nFlags, CPoint point)
//{
//	// TODO: Add your message handler code here and/or call default
//	CString buffer;
//	buffer.Format(TEXT("x=%d,y=%d"), point.x, point.y);
//	static_cast<CCanvasWnd*>(GetParentFrame())->m_statusBar.SetPaneText(3, buffer);
//}