// CanvasDoc.cpp : implementation file
//

#include "pch.h"
#include "CanvasDoc.h"


// CCanvasDoc

IMPLEMENT_DYNCREATE(CCanvasDoc, CDocument)

CCanvasDoc::CCanvasDoc()
{
}

BOOL CCanvasDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	m_p1 = m_p2 = CPoint(-1, -1);
	return TRUE;
}

CCanvasDoc::~CCanvasDoc()
{
}


BEGIN_MESSAGE_MAP(CCanvasDoc, CDocument)
END_MESSAGE_MAP()


// CCanvasDoc diagnostics

#ifdef _DEBUG
void CCanvasDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CCanvasDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CCanvasDoc serialization

void CCanvasDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
		ar << m_p1 << m_p2;
	}
	else
	{
		// TODO: add loading code here
		ar >> m_p1 >> m_p2;

	}
}
#endif


// CCanvasDoc commands
