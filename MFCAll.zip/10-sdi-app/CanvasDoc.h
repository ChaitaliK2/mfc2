#pragma once

// CCanvasDoc document

class CCanvasDoc : public CDocument
{
	DECLARE_DYNCREATE(CCanvasDoc)

public:
	CCanvasDoc();
	virtual ~CCanvasDoc();
#ifndef _WIN32_WCE
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
#endif
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual BOOL OnNewDocument();

public:
	CPoint m_p1;
	CPoint m_p2;

	DECLARE_MESSAGE_MAP()

};

/*
-since setter and getter to access m_p1 and m_p2 is not going to contribute
anything, we have omitted them and given public access to m_p1 and m_p2.
*/