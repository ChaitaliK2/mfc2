#pragma once



// CSDIApp

class CSDIApp : public CWinApp
{
	DECLARE_DYNCREATE(CSDIApp)

public:
	CSDIApp();           // protected constructor used by dynamic creation
	virtual ~CSDIApp();

public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

protected:
	DECLARE_MESSAGE_MAP()
};


