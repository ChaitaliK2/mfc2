// SDIApp.cpp : implementation file
//

#include "pch.h"
#include "SDIApp.h"
#include "CanvasWnd.h"
#include "CanvasDoc.h"
#include "CanvasView.h"
#include "resource.h"

// CSDIApp
CSDIApp theApp;
IMPLEMENT_DYNCREATE(CSDIApp, CWinApp)

CSDIApp::CSDIApp(){}

CSDIApp::~CSDIApp(){}

BOOL CSDIApp::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	CSingleDocTemplate* pDocTemplate = new CSingleDocTemplate(
	IDR_CANVAS_RES,
	RUNTIME_CLASS(CCanvasDoc),
	RUNTIME_CLASS(CCanvasWnd),
	RUNTIME_CLASS(CCanvasView));
	AddDocTemplate(pDocTemplate);

	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	return ProcessShellCommand(cmdInfo);
}

int CSDIApp::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinApp::ExitInstance();
}

BEGIN_MESSAGE_MAP(CSDIApp, CWinApp)
	ON_COMMAND(ID_FILE_NEW,CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()


// CSDIApp message handlers
