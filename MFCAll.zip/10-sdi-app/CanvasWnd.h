#pragma once


// CCanvasWnd frame

class CCanvasWnd : public CFrameWnd
{
	DECLARE_DYNCREATE(CCanvasWnd)
protected:
	CCanvasWnd();           // protected constructor used by dynamic creation
	virtual ~CCanvasWnd();

protected:
	DECLARE_MESSAGE_MAP()
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);

private:
	CSplitterWnd m_splitterWnd;
	CToolBar m_toolBar;
public:
	CStatusBar m_statusBar;
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
};


