//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by 15-Practice.rc

#define ID_BUTTON_CLEAR					101
#define ID_BUTTON_CALCULATE				102
#define	ID_STATIC_PRINCIPAL				103
#define ID_STATIC_INTERESTRATE			104
#define ID_STATIC_TERM					105
#define ID_STATIC_RESULT				106
#define ID_EDIT_PRINCIPAL				107
#define ID_EDIT_INTERESTRATE			108
#define ID_EDIT_TERM					109
// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
