
// ChildView.h : interface of the CChildView class
//


#pragma once


// CChildView window

class CChildView : public CWnd
{
// Construction
public:
	CChildView();

// Attributes
public:

// Operations
public:

// Overrides
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual ~CChildView();

	// Generated message map functions
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnButtonCalculate();
	afx_msg void OnButtonClear();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);

private:
	CButton m_btnClear;
	CButton m_btnCalculate;
	CStatic m_principal;
	CStatic m_interestRate;
	CStatic m_term;
	CStatic m_interest;


public:
	afx_msg void OnEditInterestRate();
};

