
// ChildView.cpp : implementation of the CChildView class
//

#include "pch.h"
#include "framework.h"
#include "15-Practice.h"
#include "ChildView.h"
#include "Resource.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_COMMAND(ID_Button_Calculate, &CChildView::OnButtonCalculate)
	ON_COMMAND(ID_Button_Clear, &CChildView::OnButtonClear)
	ON_WM_CREATE()
	ON_COMMAND(ID_Edit_Interestrate, &CChildView::OnEditInterestRate)
END_MESSAGE_MAP()



// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(nullptr, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), nullptr);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	
	// Do not call CWnd::OnPaint() for painting messages
}



void CChildView::OnButtonCalculate()
{
	// TODO: Add your command handler code here
}


void CChildView::OnButtonClear()
{
	// TODO: Add your command handler code he																					re
}


int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  Add your specialized creation code here
	m_btnClear.Create(TEXT("CLEAR"), WS_BORDER | WS_CHILD | WS_VISIBLE , CRect(310, 300, 510, 340), this, ID_Button_Clear);
	m_btnCalculate.Create(TEXT("CALCULATE"), WS_BORDER | WS_CHILD | WS_VISIBLE, CRect(80, 300, 260, 340), this, ID_Button_Calculate);
	m_principal.Create(_T("Principal"), WS_CHILD | WS_VISIBLE | SS_CENTER | SS_CENTERIMAGE,CRect(80, 30, 200, 80), this,ID_Static1);
	m_interestRate.Create(_T("Interest Rate"), WS_CHILD | WS_VISIBLE | SS_CENTER | SS_CENTERIMAGE, CRect(80, 100, 240, 140), this, ID_Static2);
	m_term.Create(_T("Term"), WS_CHILD | WS_VISIBLE | SS_CENTER | SS_CENTERIMAGE, CRect(80, 170, 250, 200), this, ID_Static3);
	m_interest.Create(_T("Interest"), WS_CHILD | WS_VISIBLE | SS_CENTER | SS_CENTERIMAGE, CRect(80, 170, 250, 200), this, ID_Static2);

	return 0;
}


void CChildView::OnEditInterestRate()
{
	// TODO: Add your command handler code here
}
