//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by 11-mdi-app.rc
//
#define IDR_LINE_RES                    102
#define IDR_MDI_APP                     103
#define IDR_ELLIPSE_RES                 104
#define ID_ACTION_AREA                40006
#define ID_ACTION_PEREMETER           40007
#define ID_HELP_ABOUTMDIAPP             40008
#define ID_ACTION_LENGTH                40009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40015
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
