// MDIApp.cpp : implementation file
//

#include "pch.h"
#include "MDIApp.h"
#include "MDIWnd.h"
#include "EllipseDoc.h"
#include "EllipseView.h"
#include "EllipseWnd.h"
#include "LineDoc.h"
#include "LineView.h"
#include "LineWnd.h"
#include "resource.h"


// CMDIApp

CMDIApp theApp;
IMPLEMENT_DYNCREATE(CMDIApp, CWinApp)

CMDIApp::CMDIApp()
{
}

CMDIApp::~CMDIApp()
{
}

BOOL CMDIApp::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	CMultiDocTemplate* pEllipseDoc = new CMultiDocTemplate(
		IDR_ELLIPSE_RES,
		RUNTIME_CLASS(CEllipseDoc),RUNTIME_CLASS(CEllipseWnd),RUNTIME_CLASS(CEllipseView));
	AddDocTemplate(pEllipseDoc);

	CMultiDocTemplate* pLineDoc = new CMultiDocTemplate(
		IDR_LINE_RES,
		RUNTIME_CLASS(CLineDoc), RUNTIME_CLASS(CLineWnd), RUNTIME_CLASS(CLineView));
	AddDocTemplate(pLineDoc);

	CMDIWnd* pMDIWnd = new CMDIWnd();
	pMDIWnd->LoadFrame(IDR_MDI_APP);
	pMDIWnd->ShowWindow(m_nCmdShow);
	m_pMainWnd = pMDIWnd;
	return TRUE;
}

int CMDIApp::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinApp::ExitInstance();
}

BEGIN_MESSAGE_MAP(CMDIApp, CWinApp)
	ON_COMMAND(ID_FILE_NEW, &CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, &CWinApp::OnFileOpen)
END_MESSAGE_MAP()


// CMDIApp message handlers
