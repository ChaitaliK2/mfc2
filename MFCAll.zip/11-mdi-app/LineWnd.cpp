// LineWnd.cpp : implementation file
//

#include "pch.h"
#include "LineWnd.h"


// CLineWnd

IMPLEMENT_DYNCREATE(CLineWnd, CMDIChildWnd)

CLineWnd::CLineWnd()
{

}

CLineWnd::~CLineWnd()
{
}


BEGIN_MESSAGE_MAP(CLineWnd, CMDIChildWnd)
END_MESSAGE_MAP()


// CLineWnd message handlers
