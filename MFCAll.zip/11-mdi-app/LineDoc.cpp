// LineDoc.cpp : implementation file
//

#include "pch.h"
#include "LineDoc.h"


// CLineDoc

IMPLEMENT_DYNCREATE(CLineDoc, CDocument)

CLineDoc::CLineDoc()
{
}

BOOL CLineDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	m_p1 = m_p2 = CPoint(-1, -1);
	return TRUE;
}

CLineDoc::~CLineDoc()
{
}


BEGIN_MESSAGE_MAP(CLineDoc, CDocument)
END_MESSAGE_MAP()


// CLineDoc diagnostics

#ifdef _DEBUG
void CLineDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CLineDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CLineDoc serialization

void CLineDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
		ar << m_p1 << m_p2;
	}
	else
	{
		// TODO: add loading code here
		ar >> m_p1 >> m_p2;
	}
}
#endif


// CLineDoc commands
