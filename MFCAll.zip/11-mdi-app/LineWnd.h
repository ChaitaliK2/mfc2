#pragma once


// CLineWnd frame

class CLineWnd : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CLineWnd)
protected:
	CLineWnd();           // protected constructor used by dynamic creation
	virtual ~CLineWnd();

protected:
	DECLARE_MESSAGE_MAP()
};


