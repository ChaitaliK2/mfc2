#pragma once


// CMDIWnd frame

class CMDIWnd : public CMDIFrameWnd
{
	DECLARE_DYNCREATE(CMDIWnd)
public:
	CMDIWnd();           // protected constructor used by dynamic creation
	virtual ~CMDIWnd();

protected:
	DECLARE_MESSAGE_MAP()
};


