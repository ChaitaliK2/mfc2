// MDIWnd.cpp : implementation file
//

#include "pch.h"
#include "MDIWnd.h"


// CMDIWnd

IMPLEMENT_DYNCREATE(CMDIWnd, CMDIFrameWnd)

CMDIWnd::CMDIWnd()
{

}

CMDIWnd::~CMDIWnd()
{
}


BEGIN_MESSAGE_MAP(CMDIWnd, CMDIFrameWnd)
END_MESSAGE_MAP()


// CMDIWnd message handlers
