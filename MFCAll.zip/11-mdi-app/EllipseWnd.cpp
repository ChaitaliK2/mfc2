// EllipseWnd.cpp : implementation file
//

#include "pch.h"
#include "EllipseWnd.h"


// CEllipseWnd

IMPLEMENT_DYNCREATE(CEllipseWnd, CMDIChildWnd)

CEllipseWnd::CEllipseWnd()
{

}

CEllipseWnd::~CEllipseWnd()
{
}


BEGIN_MESSAGE_MAP(CEllipseWnd, CMDIChildWnd)
END_MESSAGE_MAP()


// CEllipseWnd message handlers
