// LineView.cpp : implementation file
//

#include "pch.h"
#include "LineView.h"
#include "LineDoc.h"
#include "LineWnd.h"

// CLineView

IMPLEMENT_DYNCREATE(CLineView, CView)

CLineView::CLineView()
{

}

CLineView::~CLineView()
{
}

BEGIN_MESSAGE_MAP(CLineView, CView)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()


// CLineView drawing

void CLineView::OnDraw(CDC* pDC)
{
	CLineDoc* pDoc = dynamic_cast<CLineDoc*>(GetDocument());

	// TODO: add draw code here
	pDC->MoveTo(pDoc->m_p1);
	pDC->LineTo(pDoc->m_p2);
}


// CLineView diagnostics

#ifdef _DEBUG
void CLineView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CLineView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
#endif //_DEBUG


// CLineView message handlers


void CLineView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	dynamic_cast<CLineDoc*>(GetDocument())->m_p1 = point;
}


void CLineView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	dynamic_cast<CLineDoc*>(GetDocument())->m_p2 = point;
	dynamic_cast<CLineDoc*>(GetDocument())->UpdateAllViews(NULL);
}
