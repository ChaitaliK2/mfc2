#pragma once



// CMDIApp

class CMDIApp : public CWinApp
{
	DECLARE_DYNCREATE(CMDIApp)

public:
	CMDIApp();           // protected constructor used by dynamic creation
	virtual ~CMDIApp();

public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

protected:
	DECLARE_MESSAGE_MAP()
};


