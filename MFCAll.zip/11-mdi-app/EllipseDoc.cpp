// EllipseDoc.cpp : implementation file
//

#include "pch.h"
#include "EllipseDoc.h"


// CEllipseDoc

IMPLEMENT_DYNCREATE(CEllipseDoc, CDocument)

CEllipseDoc::CEllipseDoc()
{
}

BOOL CEllipseDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	m_p1 = m_p2 = CPoint(-1, -1);
	return TRUE;
}

CEllipseDoc::~CEllipseDoc()
{
}


BEGIN_MESSAGE_MAP(CEllipseDoc, CDocument)
END_MESSAGE_MAP()


// CEllipseDoc diagnostics

#ifdef _DEBUG
void CEllipseDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CEllipseDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CEllipseDoc serialization

void CEllipseDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
		ar << m_p1 << m_p2;
	}
	else
	{
		// TODO: add loading code here
		ar >> m_p1 >> m_p2;
	}
}
#endif


// CEllipseDoc commands
