// EllipseView.cpp : implementation file
//

#include "pch.h"
#include "EllipseView.h"
#include "EllipseDoc.h"
#include "EllipseWnd.h"

// CEllipseView

IMPLEMENT_DYNCREATE(CEllipseView, CView)

CEllipseView::CEllipseView()
{

}

CEllipseView::~CEllipseView()
{
}

BEGIN_MESSAGE_MAP(CEllipseView, CView)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()


// CEllipseView drawing

void CEllipseView::OnDraw(CDC* pDC)
{
	CEllipseDoc* pDoc = dynamic_cast<CEllipseDoc*>(GetDocument());

	// TODO: add draw code here
	pDC->Rectangle(pDoc->m_p1.x, pDoc->m_p1.y, pDoc->m_p2.x, pDoc->m_p2.y);
}


// CEllipseView diagnostics

#ifdef _DEBUG
void CEllipseView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CEllipseView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
#endif //_DEBUG


// CEllipseView message handlers


void CEllipseView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	dynamic_cast<CEllipseDoc*>(GetDocument())->m_p1 = point;

}


void CEllipseView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	dynamic_cast<CEllipseDoc*>(GetDocument())->m_p2 = point;
	dynamic_cast<CEllipseDoc*>(GetDocument())->UpdateAllViews(NULL);
}
