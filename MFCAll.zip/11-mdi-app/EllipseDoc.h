#pragma once

// CEllipseDoc document

class CEllipseDoc : public CDocument
{
	DECLARE_DYNCREATE(CEllipseDoc)

public:
	CEllipseDoc();
	virtual ~CEllipseDoc();
#ifndef _WIN32_WCE
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
#endif
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual BOOL OnNewDocument();

public:
	CPoint m_p1;
	CPoint m_p2;
	DECLARE_MESSAGE_MAP()
};
