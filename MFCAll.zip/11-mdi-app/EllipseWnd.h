#pragma once


// CEllipseWnd frame

class CEllipseWnd : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CEllipseWnd)
protected:
	CEllipseWnd();           // protected constructor used by dynamic creation
	virtual ~CEllipseWnd();

protected:
	DECLARE_MESSAGE_MAP()
};


