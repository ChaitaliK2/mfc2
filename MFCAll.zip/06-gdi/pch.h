#pragma once
#include<sdkddkver.h>
#include<afxwin.h>
//#include<>