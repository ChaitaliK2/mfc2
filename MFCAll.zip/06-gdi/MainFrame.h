#pragma once
class CMainFrame :
    public CFrameWnd
{

    DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnLButtonDown(UINT nFlags,CPoint point);
    afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
    afx_msg void OnPaint();   

private:
    CPoint m_p1;
    CPoint m_p2;
};

