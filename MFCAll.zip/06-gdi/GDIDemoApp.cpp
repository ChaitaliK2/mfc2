#include "pch.h"
#include "GDIDemoApp.h"
#include "MainFrame.h"

CGDIDemoApp theApp;

BOOL CGDIDemoApp::InitInstance()
{
	CMainFrame* pFrame = new CMainFrame();
	pFrame->Create(NULL, TEXT("GDI Demo"));
	pFrame->ShowWindow(m_nCmdShow);
	m_pMainWnd = pFrame;
	return TRUE;
	
}