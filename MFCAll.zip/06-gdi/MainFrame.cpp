
#include "pch.h"
#include "MainFrame.h"

BEGIN_MESSAGE_MAP(CMainFrame,CFrameWnd)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_PAINT()
	
END_MESSAGE_MAP()

void CMainFrame::OnLButtonDown(UINT nFlags, CPoint point)
{
	m_p1 = point;
}

void CMainFrame::OnLButtonUp(UINT nFlags, CPoint point)
{
	m_p2 = point;
	Invalidate();
}

void CMainFrame::OnPaint()
{
	CPaintDC dc(this);
	CPen bluePen(PS_SOLID, 3, RGB(0, 0, 255));
	CBrush redBrush(RGB(180,0,0));
	//redBrush.CreateSolidBrush(RGB(255, 0, 0));

	CBrush* pOrgBrush = dc.SelectObject(&redBrush);
	CPen* pOrgPen = dc.SelectObject(&bluePen);

	/*dc.MoveTo(m_p1);
	dc.LineTo(m_p2);*/

	
	/*CImage image;

	image.Load(TEXT("smile.png"));

	image.StretchBlt(dc.GetSafeHdc(), 10, 10, 200, 200);*/

	dc.Rectangle(100, 100, 200, 200);
	//dc.Rectangle(m_p1.x, m_p1.y, m_p2.x, m_p2.y);
	//dc.Ellipse(m_p1.x, m_p1.y, m_p2.x, m_p2.y);

	dc.SelectObject(pOrgPen);
	dc.SelectObject(pOrgBrush);
}

