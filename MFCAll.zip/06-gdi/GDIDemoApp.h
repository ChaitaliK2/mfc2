#pragma once
#include <afxwin.h>
class CGDIDemoApp :
    public CWinApp
{
public:
    BOOL InitInstance()override;
};

