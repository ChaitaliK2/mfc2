#include "pch.h"
#include "Line.h"

CLine::CLine(CPoint p1, CPoint p2, COLORREF borderColor, int borderWidth, COLORREF brushColor)
	: CShape(p1, p2, borderColor, borderWidth, brushColor) {}

void CLine::Draw(CDC* pDC)
{
	CPoint p1 = GetP1();
	CPoint p2 = GetP2();

	CPen pen(PS_SOLID, GetBorderWidth(), GetBorderColor());
	CBrush brush(GetBrushColor());

	CBrush* pOrgBrush = pDC->SelectObject(&brush);
	CPen* pOrgPen = pDC->SelectObject(&pen);

	pDC->MoveTo(p1);
	pDC->LineTo(p2);

	pDC->SelectObject(pOrgPen);
	pDC->SelectObject(pOrgBrush);
}