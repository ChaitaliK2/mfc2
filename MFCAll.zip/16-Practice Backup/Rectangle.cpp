#include "pch.h"
#include "Rectangle.h"

CRectangle::CRectangle(CPoint p1, CPoint p2, COLORREF borderColor, int borderWidth, COLORREF brushColor) 
	: CShape(p1,p2,borderColor,borderWidth,brushColor) {}

void CRectangle::Draw(CDC* pDC)
{
	CPoint p1 = GetP1();
	CPoint p2 = GetP2();

	CPen pen(PS_SOLID, GetBorderWidth(), GetBorderColor());
	CBrush brush(GetBrushColor());

	CBrush* pOrgBrush = pDC->SelectObject(&brush);
	CPen* pOrgPen = pDC->SelectObject(&pen);

	pDC->Rectangle(p1.x, p1.y, p2.x, p2.y);

	pDC->SelectObject(pOrgPen);
	pDC->SelectObject(pOrgBrush);
}