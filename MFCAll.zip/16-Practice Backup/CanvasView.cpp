// CanvasView.cpp : implementation file
//

#include "pch.h"
#include "CanvasView.h"
#include "CanvasDoc.h"
#include "CanvasWnd.h"
#include "Rectangle.h"
#include "Ellipse.h"
#include "Line.h"
#include "resource.h"

// CCanvasView

IMPLEMENT_DYNCREATE(CCanvasView, CView)

CCanvasView::CCanvasView()
{

}

CCanvasView::~CCanvasView()
{
}

BEGIN_MESSAGE_MAP(CCanvasView, CView)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()


// CCanvasView drawing

void CCanvasView::OnDraw(CDC* pDC)
{
	CCanvasDoc* pDoc = dynamic_cast<CCanvasDoc*>(GetDocument());
	
	// TODO: add draw code here
	for (int i = 0; i < pDoc->m_shapes.GetCount(); i++)
	{
		pDoc->m_shapes.ElementAt(i)->Draw(pDC);
	}
}


// CCanvasView diagnostics

#ifdef _DEBUG
void CCanvasView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CCanvasView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
#endif //_DEBUG


// CCanvasView message handlers


void CCanvasView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	m_p1 = point;
}


void CCanvasView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	m_p2 = point;
	CShape* pShape = nullptr;
	CCanvasWnd* pFrame = dynamic_cast<CCanvasWnd*>(GetParentFrame());
	COLORREF borderColor = RGB(pFrame->m_redBorder ? 255 : 0, pFrame->m_greenBorder ? 255 : 0, pFrame->m_blueBorder ? 255 : 0);
	COLORREF brushColor = RGB(pFrame->m_redBrush ? 255 : 0, pFrame->m_greenBrush ? 255 : 0, pFrame->m_blueBrush ? 255 : 0);
	int borderWidth = pFrame->m_pixcel;
	switch (pFrame->m_shape)
	{
	case 1:
		pShape = new CRectangle(m_p1, m_p2, borderColor, borderWidth, brushColor);
		break;
	case 2:
		pShape = new CEllipse(m_p1, m_p2, borderColor, borderWidth, brushColor);
		break;
	case 3:
		pShape = new CLine(m_p1, m_p2, borderColor, borderWidth, brushColor);
		break;
	}
	CCanvasDoc* pDoc = dynamic_cast<CCanvasDoc*>(GetDocument());
	pDoc->m_shapes.Add(pShape);
	pDoc->UpdateAllViews(NULL);
}






