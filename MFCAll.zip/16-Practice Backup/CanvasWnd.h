#pragma once


// CCanvasWnd frame

class CCanvasWnd : public CFrameWnd
{
	DECLARE_DYNCREATE(CCanvasWnd)
protected:
	CCanvasWnd();           // protected constructor used by dynamic creation
	virtual ~CCanvasWnd();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnActionRectangle();
	afx_msg void OnActionEclipse();
	afx_msg void OnActionLine();
	afx_msg void OnAction2Picxel();
	afx_msg void OnAction1Pixcel();
	afx_msg void OnAction3picxel();
	afx_msg void OnActionBrushRed();
	afx_msg void OnActionBrushGreen();
	afx_msg void OnActionBrushBlue();
	afx_msg void OnActionBorderRed();
	afx_msg void OnActionBorderGreen();
	afx_msg void OnActionBorderBlue();
public:
	int m_shape;
	bool m_redBorder;
	bool m_greenBorder;
	bool m_blueBorder;
	int m_pixcel;
	bool m_redBrush;
	bool m_greenBrush;
	bool m_blueBrush;
};


