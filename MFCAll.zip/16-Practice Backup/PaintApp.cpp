// PaintApp.cpp : implementation file
//

#include "pch.h"
#include "PaintApp.h"
#include "CanvasDoc.h"
#include "CanvasView.h"
#include "CanvasWnd.h"
#include "resource.h"
// CPaintApp

CPaintApp theApp;
IMPLEMENT_DYNCREATE(CPaintApp, CWinApp)

CPaintApp::CPaintApp()
{
}

CPaintApp::~CPaintApp()
{
}

BOOL CPaintApp::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	CSingleDocTemplate* pDocTemplate = new CSingleDocTemplate(
		IDR_APP_RES,
		RUNTIME_CLASS(CCanvasDoc),
		RUNTIME_CLASS(CCanvasWnd),
		RUNTIME_CLASS(CCanvasView));
	AddDocTemplate(pDocTemplate);

	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	return ProcessShellCommand(cmdInfo);
}

int CPaintApp::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinApp::ExitInstance();
}

BEGIN_MESSAGE_MAP(CPaintApp, CWinApp)
END_MESSAGE_MAP()


// CPaintApp message handlers
