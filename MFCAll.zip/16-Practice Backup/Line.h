#pragma once
#include "Shape.h"
class CLine :
    public CShape
{
public:
    CLine(CPoint p1, CPoint p2, COLORREF borderColor, int borderWidth, COLORREF brushColor);

public:
    void Draw(CDC* pDC) override;
};

