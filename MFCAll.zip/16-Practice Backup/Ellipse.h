#pragma once
#include "Shape.h"
class CEllipse :
    public CShape
{
public:
    CEllipse(CPoint p1, CPoint p2, COLORREF borderColor, int borderWidth, COLORREF brushColor);

public:
    void Draw(CDC* pDC) override;
};

