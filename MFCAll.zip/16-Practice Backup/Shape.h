#pragma once
class CShape
{
public:
	CShape(CPoint p1, CPoint p2, COLORREF borderColor, int borderWidth, COLORREF brushColor);
	virtual ~CShape();

public:
	CPoint GetP1() const;
	CPoint GetP2() const;
	COLORREF GetBorderColor() const;
	int GetBorderWidth() const;
	COLORREF GetBrushColor() const;
	void SetP1(CPoint p1);
	void SetP2(CPoint p2);
	void SetBorderColor(COLORREF borderColor);
	void SetBorderWidth(int borderWidth);
	void SetBrushColor(COLORREF brushColor);

public: 
	virtual void Draw(CDC* pDC) = 0;

private:
	CPoint m_p1;
	CPoint m_p2;
	COLORREF m_borderColor;
	COLORREF m_brushColor;
	int m_borderWidth;
};

