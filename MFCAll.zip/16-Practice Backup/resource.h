//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by 16-Practice.rc
//

#define IDR_APP_RES                     105
#define ID_PAINT_RECTANGLE              40001
#define ID_PAINT_ECLIPSE                40002
#define ID_PAINT_LINE                   40003
#define ID_BORDER_RED                   40005
#define ID_BORDER_GREEN                 40006
#define ID_BORDER_BLUE                  40007
#define ID_BORDER_1PIXCEL               40008
#define ID_BORDER_2PICXEL               40009
#define ID_BORDER_3PICXEL               40010
#define ID_BRUSH_RED                    40011
#define ID_BRUSH_GREEN                  40012
#define ID_BRUSH_BLUE                   40013
//#define ID_APP_EXIT                     0xE141

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
