// CanvasDoc.cpp : implementation file
//

#include "pch.h"
#include "CanvasDoc.h"


// CCanvasDoc

IMPLEMENT_DYNCREATE(CCanvasDoc, CDocument)

CCanvasDoc::CCanvasDoc()
{
}

BOOL CCanvasDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	return TRUE;
}

CCanvasDoc::~CCanvasDoc()
{
	for (int i = 0; i < m_shapes.GetCount(); i++)
	{
	    delete m_shapes.ElementAt(i);
	}
}


BEGIN_MESSAGE_MAP(CCanvasDoc, CDocument)
END_MESSAGE_MAP()


// CCanvasDoc diagnostics

#ifdef _DEBUG
void CCanvasDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CCanvasDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CCanvasDoc serialization

void CCanvasDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}
#endif


// CCanvasDoc commands
