#include "pch.h"
#include "Shape.h"

CShape::CShape(CPoint p1, CPoint p2, COLORREF borderColor, int borderWidth, COLORREF brushColor)
	:m_p1(p1),
	 m_p2(p2),
	 m_borderColor(borderColor),
	 m_borderWidth(borderWidth),
	 m_brushColor(brushColor) 
{}

CShape::~CShape()
{
}

CPoint CShape::GetP1() const
{
	return m_p1;
}

void CShape::SetP1(CPoint p1)
{
	m_p1 = p1;
}

CPoint CShape::GetP2() const
{
	return m_p2;
}

void CShape::SetP2(CPoint p2)
{
	m_p2 = p2;
}

COLORREF CShape::GetBorderColor() const
{
	return m_borderColor;
}

void CShape::SetBorderColor(COLORREF borderColor)
{
	m_borderColor = borderColor;
}

int CShape::GetBorderWidth() const
{
	return m_borderWidth;
}

void CShape::SetBorderWidth(int borderWidth)
{
	m_borderWidth = borderWidth;
}

COLORREF CShape::GetBrushColor() const
{
	return m_brushColor;
}

void CShape::SetBrushColor(COLORREF brushColor)
{
	m_brushColor = brushColor;
}