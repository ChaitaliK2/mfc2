// CanvasWnd.cpp : implementation file
//

#include "pch.h"
#include "CanvasWnd.h"
#include "resource.h"

// CCanvasWnd

IMPLEMENT_DYNCREATE(CCanvasWnd, CFrameWnd)

CCanvasWnd::CCanvasWnd()
{

}

CCanvasWnd::~CCanvasWnd()
{
}


BEGIN_MESSAGE_MAP(CCanvasWnd, CFrameWnd)
	ON_WM_CREATE()
	ON_COMMAND(ID_PAINT_RECTANGLE, &CCanvasWnd::OnActionRectangle)
	ON_COMMAND(ID_PAINT_ECLIPSE, &CCanvasWnd::OnActionEclipse)
	ON_COMMAND(ID_PAINT_LINE, &CCanvasWnd::OnActionLine)
	ON_COMMAND(ID_BORDER_2PICXEL, &CCanvasWnd::OnAction2Picxel)
	ON_COMMAND(ID_BORDER_1PIXCEL, &CCanvasWnd::OnAction1Pixcel)
	ON_COMMAND(ID_BORDER_3PICXEL, &CCanvasWnd::OnAction3picxel)
	ON_COMMAND(ID_BRUSH_RED, &CCanvasWnd::OnActionBrushRed)
	ON_COMMAND(ID_BRUSH_GREEN, &CCanvasWnd::OnActionBrushGreen)
	ON_COMMAND(ID_BRUSH_BLUE, &CCanvasWnd::OnActionBrushBlue)
	ON_COMMAND(ID_BORDER_RED, &CCanvasWnd::OnActionBorderRed)
	ON_COMMAND(ID_BORDER_GREEN, &CCanvasWnd::OnActionBorderGreen)
	ON_COMMAND(ID_BORDER_BLUE, &CCanvasWnd::OnActionBorderBlue)
END_MESSAGE_MAP()


// CCanvasWnd message handlers


int CCanvasWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  Add your specialized creation code here
	CMenu* pMenu = GetMenu();
	CMenu* pActionMenu = pMenu->GetSubMenu(1);
	pActionMenu->CheckMenuRadioItem(ID_BORDER_1PIXCEL, ID_BORDER_3PICXEL, ID_BORDER_1PIXCEL, MF_BYCOMMAND);
	CMenu* pActionMenu1 = pMenu->GetSubMenu(0);
	pActionMenu1->CheckMenuRadioItem(ID_PAINT_RECTANGLE, ID_PAINT_LINE, ID_PAINT_RECTANGLE, MF_BYCOMMAND);

	return 0;
}

void CCanvasWnd::OnActionRectangle()
{
	// TODO: Add your command handler code here
	CMenu* pMenu = GetMenu();
	CMenu* pActionMenu1 = pMenu->GetSubMenu(0);
	m_shape = 1;
	pActionMenu1->CheckMenuRadioItem(ID_PAINT_RECTANGLE, ID_PAINT_LINE, ID_PAINT_RECTANGLE, MF_BYCOMMAND);
}


void CCanvasWnd::OnActionEclipse()
{
	// TODO: Add your command handler code here
	CMenu* pMenu = GetMenu();
	CMenu* pActionMenu1 = pMenu->GetSubMenu(0);
	m_shape = 2;
	pActionMenu1->CheckMenuRadioItem(ID_PAINT_RECTANGLE, ID_PAINT_LINE, ID_PAINT_ECLIPSE, MF_BYCOMMAND);
}


void CCanvasWnd::OnActionLine()
{
	// TODO: Add your command handler code here
	CMenu* pMenu = GetMenu();
	CMenu* pActionMenu1 = pMenu->GetSubMenu(0);
	m_shape = 3;
	pActionMenu1->CheckMenuRadioItem(ID_PAINT_RECTANGLE, ID_PAINT_LINE, ID_PAINT_LINE, MF_BYCOMMAND);
}

void CCanvasWnd::OnAction2Picxel()
{
	// TODO: Add your command handler code here
	CMenu* pMenu = GetMenu();
	CMenu* pActionMenu = pMenu->GetSubMenu(1);
	m_pixcel = 2;
	pActionMenu->CheckMenuRadioItem(ID_BORDER_1PIXCEL, ID_BORDER_3PICXEL, ID_BORDER_2PICXEL, MF_BYCOMMAND);
}


void CCanvasWnd::OnAction1Pixcel()
{
	// TODO: Add your command handler code here
	CMenu* pMenu = GetMenu();
	CMenu* pActionMenu = pMenu->GetSubMenu(1);
	m_pixcel = 1;
	pActionMenu->CheckMenuRadioItem(ID_BORDER_1PIXCEL, ID_BORDER_3PICXEL, ID_BORDER_1PIXCEL, MF_BYCOMMAND);
}


void CCanvasWnd::OnAction3picxel()
{
	// TODO: Add your command handler code here
	CMenu* pMenu = GetMenu();
	CMenu* pActionMenu = pMenu->GetSubMenu(1);
	m_pixcel = 3;
	pActionMenu->CheckMenuRadioItem(ID_BORDER_1PIXCEL, ID_BORDER_3PICXEL, ID_BORDER_1PIXCEL, MF_BYCOMMAND);
}


void CCanvasWnd::OnActionBrushRed()
{
	// TODO: Add your command handler code here
	CMenu* pMenu = GetMenu();
	CMenu* pActionMenu = pMenu->GetSubMenu(2);
	m_redBrush = TRUE;
	UINT checkState = pActionMenu->GetMenuState(ID_BRUSH_RED, MF_BYCOMMAND);
	if (checkState & MF_CHECKED)
	{
		m_redBrush = FALSE;
		pActionMenu->CheckMenuItem(ID_BRUSH_RED, MF_UNCHECKED | MF_BYCOMMAND);
	}
	else
	{
		m_redBrush = TRUE;
		pActionMenu->CheckMenuItem(ID_BRUSH_RED, MF_CHECKED | MF_BYCOMMAND);
	}
}


void CCanvasWnd::OnActionBrushGreen()
{
	// TODO: Add your command handler code here
	CMenu* pMenu = GetMenu();
	CMenu* pActionMenu = pMenu->GetSubMenu(2);
	m_greenBrush = TRUE;
	UINT checkState = pActionMenu->GetMenuState(ID_BRUSH_GREEN, MF_BYCOMMAND);
	if (checkState & MF_CHECKED)
	{
		m_greenBrush = FALSE;
		pActionMenu->CheckMenuItem(ID_BRUSH_GREEN, MF_UNCHECKED | MF_BYCOMMAND);
	}
	else
	{
		m_greenBrush = TRUE;
		pActionMenu->CheckMenuItem(ID_BRUSH_GREEN, MF_CHECKED | MF_BYCOMMAND);
	}
}


void CCanvasWnd::OnActionBrushBlue()
{
	// TODO: Add your command handler code here
	CMenu* pMenu = GetMenu();
	CMenu* pActionMenu = pMenu->GetSubMenu(2);
	m_blueBrush = TRUE;
	UINT checkState = pActionMenu->GetMenuState(ID_BRUSH_BLUE, MF_BYCOMMAND);
	if (checkState & MF_CHECKED)
	{
		m_blueBrush = FALSE;
		pActionMenu->CheckMenuItem(ID_BRUSH_BLUE, MF_UNCHECKED | MF_BYCOMMAND);
	}
	else
	{
		m_blueBrush = TRUE;
		pActionMenu->CheckMenuItem(ID_BRUSH_BLUE, MF_CHECKED | MF_BYCOMMAND);
	}
}


void CCanvasWnd::OnActionBorderRed()
{
	// TODO: Add your command handler code here
	CMenu* pMenu = GetMenu();
	CMenu* pActionMenu = pMenu->GetSubMenu(1);
	m_redBorder = TRUE;
	UINT checkState = pActionMenu->GetMenuState(ID_BORDER_RED, MF_BYCOMMAND);
	if (checkState & MF_CHECKED)
	{
		m_redBorder = FALSE;
		pActionMenu->CheckMenuItem(ID_BORDER_RED, MF_UNCHECKED | MF_BYCOMMAND);
	}
	else
	{
		m_redBorder = TRUE;
		pActionMenu->CheckMenuItem(ID_BORDER_RED, MF_CHECKED | MF_BYCOMMAND);
	}
}


void CCanvasWnd::OnActionBorderGreen()
{
	// TODO: Add your command handler code here
	CMenu* pMenu = GetMenu();
	CMenu* pActionMenu = pMenu->GetSubMenu(1);
	m_greenBorder = TRUE;
	UINT checkState = pActionMenu->GetMenuState(ID_BORDER_GREEN, MF_BYCOMMAND);
	if (checkState & MF_CHECKED)
	{
		m_greenBorder = FALSE;
		pActionMenu->CheckMenuItem(ID_BORDER_GREEN, MF_UNCHECKED | MF_BYCOMMAND);
	}
	else
	{
		m_greenBorder = TRUE;
		pActionMenu->CheckMenuItem(ID_BORDER_GREEN, MF_CHECKED | MF_BYCOMMAND);
	}
}


void CCanvasWnd::OnActionBorderBlue()
{
	// TODO: Add your command handler code here
	CMenu* pMenu = GetMenu();
	CMenu* pActionMenu = pMenu->GetSubMenu(1);
	m_blueBorder = TRUE;
	UINT checkState = pActionMenu->GetMenuState(ID_BORDER_BLUE, MF_BYCOMMAND);
	if (checkState & MF_CHECKED)
	{
		m_blueBorder = FALSE;
		pActionMenu->CheckMenuItem(ID_BORDER_BLUE, MF_UNCHECKED | MF_BYCOMMAND);
	}
	else
	{
		m_blueBorder = TRUE;
		pActionMenu->CheckMenuItem(ID_BORDER_BLUE, MF_CHECKED | MF_BYCOMMAND);
	}
}