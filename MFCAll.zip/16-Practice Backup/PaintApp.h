#pragma once



// CPaintApp

class CPaintApp : public CWinApp
{
	DECLARE_DYNCREATE(CPaintApp)

public:
	CPaintApp();           // protected constructor used by dynamic creation
	virtual ~CPaintApp();

public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

protected:
	DECLARE_MESSAGE_MAP()
};


