#pragma once
#include "Shape.h"
class CRectangle :
    public CShape
{
public:
    CRectangle(CPoint p1, CPoint p2, COLORREF borderColor, int borderWidth, COLORREF brushColor);

public:
    void Draw(CDC* pDC) override;
};

