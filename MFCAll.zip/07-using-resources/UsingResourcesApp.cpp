#include "pch.h"
#include "UsingResourcesApp.h"
#include "MainFrame.h"
#include "resource.h"

BEGIN_MESSAGE_MAP(CUsingResourcesApp, CWinApp)
	ON_COMMAND(ID_FILE_NEW,&CUsingResourcesApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, &CUsingResourcesApp::OnFileOpen)

END_MESSAGE_MAP()

CUsingResourcesApp theApp;


BOOL CUsingResourcesApp::InitInstance()
{
	CMainFrame* pFrame = new CMainFrame();

	////Load Caption string from string table resources
	//const size_t size = 64;
	//TCHAR caption[size] = { 0 };
	//::LoadString(m_hInstance, IDS_CAPTION, caption, size);

	////create window with meny and caption loaded from string table
	//pFrame->Create(NULL, caption, WS_OVERLAPPEDWINDOW, CFrameWnd::rectDefault, NULL, MAKEINTRESOURCE(IDR_MENU1));

	////Load icon resoures
	//HICON hIcon = AfxGetApp()->LoadIcon(IDI_ICON1);
	//pFrame->SetIcon(hIcon, FALSE);

	////Load accelators from accletors table
	//pFrame->LoadAccelTable(MAKEINTRESOURCE(IDR_ACCELERATOR1));

		
	pFrame->LoadFrame(IDR_APP_RES);
	pFrame->ShowWindow(m_nCmdShow);
	m_pMainWnd = pFrame;
	return TRUE;
}

void CUsingResourcesApp::OnFileNew()
{
	TRACE(TEXT("File->New Clicked\n"));
}

void CUsingResourcesApp::OnFileOpen()
{
	TRACE(TEXT("File->Open Clicked\n"));
}