#include "pch.h"
#include "MainFrame.h"
#include "resource.h"

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
    ON_WM_CREATE()
    ON_COMMAND(ID_ACTION_RADIO1, &CMainFrame::OnActionRadio1)
    ON_COMMAND(ID_ACTION_RADIO2, &CMainFrame::OnActionRadio2)
    ON_COMMAND(ID_ACTION_RADIO3, &CMainFrame::OnActionRadio3)
    ON_COMMAND(ID_ACTION_CHECKA, &CMainFrame::OnActionCheckA)
    ON_COMMAND(ID_ACTION_CHECKB, &CMainFrame::OnActionCheckB)
    ON_COMMAND(ID_ACTION_CHECKC, &CMainFrame::OnActionCheckC)
    ON_COMMAND(ID_ACTION_ENABLE, &CMainFrame::OnActionEnable)
    ON_COMMAND(ID_ACTION_VISIBLE, &CMainFrame::OnActionVisible)
    ON_COMMAND(ID_CONTEXTMENU_COPY,&CMainFrame::OnActionCopy)
    ON_COMMAND(ID_CONTEXTMENU_PASTE, &CMainFrame::OnActionPaste)
	ON_UPDATE_COMMAND_UI(ID_ACTION_ENABLE,&CMainFrame::OnUpdateActionEnable)
    ON_UPDATE_COMMAND_UI(ID_ACTION_VISIBLE, &CMainFrame::OnUpdateActionVisible)
    ON_WM_CONTEXTMENU()
END_MESSAGE_MAP()

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
    if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
        return -1;

    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
    pActionMenu->CheckMenuRadioItem(ID_ACTION_RADIO1, ID_ACTION_RADIO3, ID_ACTION_RADIO1, MF_BYCOMMAND);

    m_contextMenu.LoadMenu(IDR_MENU2);

    return 0;
}
void CMainFrame::OnActionRadio1()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
    pActionMenu->CheckMenuRadioItem(ID_ACTION_RADIO1, ID_ACTION_RADIO3, ID_ACTION_RADIO1, MF_BYCOMMAND);
}

void CMainFrame::OnActionRadio2()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
    pActionMenu->CheckMenuRadioItem(ID_ACTION_RADIO1, ID_ACTION_RADIO3, ID_ACTION_RADIO2, MF_BYCOMMAND);
}

void CMainFrame::OnActionRadio3()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
    pActionMenu->CheckMenuRadioItem(ID_ACTION_RADIO1, ID_ACTION_RADIO3, ID_ACTION_RADIO3, MF_BYCOMMAND);
}

void CMainFrame::OnActionCheckA()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
    UINT checkState = pActionMenu->GetMenuState(ID_ACTION_CHECKA, MF_BYCOMMAND);
    if (checkState & MF_CHECKED)
        pActionMenu->CheckMenuItem(ID_ACTION_CHECKA, MF_UNCHECKED | MF_BYCOMMAND);
    else
        pActionMenu->CheckMenuItem(ID_ACTION_CHECKA, MF_CHECKED | MF_BYCOMMAND);

}

void CMainFrame::OnActionCheckB()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
    UINT checkState = pActionMenu->GetMenuState(ID_ACTION_CHECKB, MF_BYCOMMAND);
    if (checkState & MF_CHECKED)
        pActionMenu->CheckMenuItem(ID_ACTION_CHECKB, MF_UNCHECKED | MF_BYCOMMAND);
    else
        pActionMenu->CheckMenuItem(ID_ACTION_CHECKB, MF_CHECKED | MF_BYCOMMAND);
}

void CMainFrame::OnActionCheckC()
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
    UINT checkState = pActionMenu->GetMenuState(ID_ACTION_CHECKC, MF_BYCOMMAND);
    if (checkState & MF_CHECKED)
        pActionMenu->CheckMenuItem(ID_ACTION_CHECKC, MF_UNCHECKED | MF_BYCOMMAND);
    else
    {
        pActionMenu->CheckMenuItem(ID_ACTION_CHECKC, MF_CHECKED | MF_BYCOMMAND);
        pActionMenu->AppendMenuW(MF_STRING, ID_ACTION_VISIBLE, TEXT("Visible"));
    }
}

void CMainFrame::OnActionEnable()
{
    TRACE(TEXT("From Action > Enable\n"));
}

void CMainFrame::OnActionVisible()
{
    TRACE(TEXT("From Action > Visible\n"));
}

void CMainFrame::OnUpdateActionEnable(CCmdUI* pCmdUI)
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
    UINT checkState = pActionMenu->GetMenuState(ID_ACTION_CHECKB, MF_BYCOMMAND);
    if (checkState & MF_CHECKED)
        pCmdUI->Enable(TRUE);
    else
        pCmdUI->Enable(FALSE);

}

void CMainFrame::OnUpdateActionVisible(CCmdUI* pCmdUI)
{
    CMenu* pMenu = GetMenu();
    CMenu* pActionMenu = pMenu->GetSubMenu(1);
    UINT checkState = pActionMenu->GetMenuState(ID_ACTION_CHECKC, MF_BYCOMMAND);
    if (checkState == MF_UNCHECKED)
        pActionMenu->RemoveMenu(ID_ACTION_VISIBLE, MF_BYCOMMAND);
    
}


void CMainFrame::OnContextMenu(CWnd* pWnd, CPoint pos)
{
    m_contextMenu.GetSubMenu(0)->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTALIGN | TPM_LEFTBUTTON, pos.x, pos.y, pWnd);
}


void CMainFrame::OnActionCopy()
{
    TRACE(TEXT("From ContextMenu > copy"));
}

void CMainFrame::OnActionPaste()
{
    TRACE(TEXT("From ContextMenu > paste"));
}