#pragma once
class CMainFrame :
    public CFrameWnd
{
    DECLARE_MESSAGE_MAP()
public:
    afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
    void OnActionRadio1();
    void OnActionRadio2();
    void OnActionRadio3();
    void OnActionCheckA();
    void OnActionCheckB();
    void OnActionCheckC();
    void OnActionEnable();
    void OnActionVisible();
    void OnActionCopy();
    void OnActionPaste();
    void OnUpdateActionEnable(CCmdUI* pCmdUI);
    void OnUpdateActionVisible(CCmdUI* pCmdUI);
    afx_msg void OnContextMenu(CWnd* pWnd,CPoint pos);

private:
    CMenu m_contextMenu;

};

