#pragma once

class CUsingResourcesApp :
    public CWinApp
{
    DECLARE_MESSAGE_MAP()
public:
    BOOL InitInstance() override;

public:
    void OnFileNew();
    void OnFileOpen();
};

