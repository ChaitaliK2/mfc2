#include "pch.h"
#include <sdkddkver.h>
#include <afxwin.h>
#include <iostream>
#include <assert.h>
#include <stdexcept>
using namespace std;

CWinApp theApp;

class CCircle : public CObject {
public:
	CCircle(int r);
public:
	int GetRadius() const;
	void SetRadius(int r);
#if _DEBUG
public:
	void AssertValid() const override;
	void Dump(CDumpContext& dc) const override;
#endif
private:
	int m_r;
};

CCircle::CCircle(int r) {
	SetRadius(r);
}

int CCircle::GetRadius() const {
#if _DEBUG
	AssertValid();
#endif
	return m_r;
}

void CCircle::SetRadius(int r) {
	if (r < 0)
		throw std::invalid_argument("Radius must be +ve number.");
	m_r = r;
}

#if _DEBUG
void CCircle::AssertValid() const {
	CObject::AssertValid();
	ASSERT(m_r >= 0);
}

void CCircle::Dump(CDumpContext& dc) const {
	CObject::Dump(dc);
	CString buffer;
	buffer.Format(TEXT("m_r = %d\n"), m_r);
	dc << buffer;
}
#endif

double GetArea(const CCircle& obj) {
#if _DEBUG
	obj.AssertValid();
#endif
	int radius = obj.GetRadius();
	return 3.14 * radius * radius;
}

int main() {
	HMODULE hModule = ::GetModuleHandle(nullptr);
	if (hModule == nullptr) {
		wprintf(L"Fatal Error: GetModuleHandle failed\n");
		return 1;
	}

	// initialize MFC and print and error on failure
	if (!AfxWinInit(hModule, nullptr, ::GetCommandLine(), 0)) {
		wprintf(L"Fatal Error: MFC initialization failed\n");
		return 1;
	}

	CCircle u(5);
	double area = GetArea(u);

#if _DEBUG
	u.Dump(afxDump);
#endif
}