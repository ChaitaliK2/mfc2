#include "pch.h"
#include <sdkddkver.h>
#include <afxwin.h>
#include <iostream>
#include <assert.h>
#include <stdexcept>
using namespace std;

CWinApp theApp;

class CCircle : public CObject {
	DECLARE_SERIAL(CCircle)
public:
	CCircle(int r = 0);
public:
	int GetRadius() const;
	void SetRadius(int r);
#if _DEBUG
public:
	void AssertValid() const override;
	void Dump(CDumpContext& dc) const override;
#endif
public:
	void Serialize(CArchive& ar);
private:
	int m_r;
};

IMPLEMENT_SERIAL(CCircle, CObject, 1)

CCircle::CCircle(int r) {
	SetRadius(r);
}

int CCircle::GetRadius() const {
#if _DEBUG
	AssertValid();
#endif
	return m_r;
}

void CCircle::SetRadius(int r) {
	if (r < 0)
		throw std::invalid_argument("Radius must be +ve number.");
	m_r = r;
}

#if _DEBUG
void CCircle::AssertValid() const {
	CObject::AssertValid();
	_ASSERT(m_r >= 0);
}

void CCircle::Dump(CDumpContext& dc) const {
	CObject::Dump(dc);
	TCHAR buffer[16];
	wsprintf(buffer, TEXT("m_r = %d"), m_r);
	dc << buffer;
}
#endif

void CCircle::Serialize(CArchive& ar) {
	CObject::Serialize(ar);
	if (ar.IsStoring())
		ar << m_r;
	else
		ar >> m_r;
}

int main() {
	HMODULE hModule = ::GetModuleHandle(nullptr);
	if (hModule == nullptr) {
		wprintf(L"Fatal Error: GetModuleHandle failed\n");
		return 1;
	}

	// initialize MFC and print and error on failure
	if (!AfxWinInit(hModule, nullptr, ::GetCommandLine(), 0)) {
		wprintf(L"Fatal Error: MFC initialization failed\n");
		return 1;
	}

	CCircle* pu = nullptr;
	CFile file(TEXT("circle.bin"), CFile::modeRead);
	CArchive ar(&file, CArchive::load);
	ar >> pu;
	ar.Close();
	file.Close();
	delete pu;
	pu = nullptr;
}

/*
- DECLARE_SERIAL, IMPLEMENT_SERIAL needs default constructor in the class.
- DECLARE_SERIAL, IMPLEMENT_SERIAL brings RTTI + Class Factory + Serialization support to the class.
- DECLARE_SERIAL  internally include DECLARE_DYNCREATE AND
- IMPLEMENT_SERIAL	internally includes IMPLEMENT_DTNACREATE
*/