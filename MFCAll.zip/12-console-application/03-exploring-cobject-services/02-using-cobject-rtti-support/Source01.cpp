#include "pch.h"
#include <iostream>
#include <assert.h>
#include <stdexcept>
using namespace std;

CWinApp theApp;

class CCircle : public CObject {
	DECLARE_DYNAMIC(CCircle)
};

IMPLEMENT_DYNAMIC(CCircle, CObject)


class CLine : public CObject {
	DECLARE_DYNAMIC(CLine)
};

IMPLEMENT_DYNAMIC(CLine, CObject)

int main() {
	HMODULE hModule = ::GetModuleHandle(nullptr);
	if (hModule == nullptr) {
		wprintf(L"Fatal Error: GetModuleHandle failed\n");
		return 1;
	}

	// initialize MFC and print and error on failure
	if (!AfxWinInit(hModule, nullptr, ::GetCommandLine(), 0)) {
		wprintf(L"Fatal Error: MFC initialization failed\n");
		return 1;
	}

	CCircle u;
	bool result = false;
	result = u.IsKindOf(RUNTIME_CLASS(CCircle)); // true
	result = u.IsKindOf(RUNTIME_CLASS(CLine));   // false
	result = u.IsKindOf(RUNTIME_CLASS(CObject));   // true
}

/*
- DECLARE_DYNAMIC, IMPLEMENT_DYNAMIC brings RTTI support to the class.
- DECLARE_DYNCREATE, IMPLEMENT_DYNCREATE brings RTTI + Class Factory support to the class.
- DECLARE_DYNCREATE  internally include DECLARE_DYNAMIC AND
- IMPLEMENT_DYNCREATE	internally includes IMPLEMENT_DYNAMIC
*/