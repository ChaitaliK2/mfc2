// 12-console-application.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include "framework.h"
#include "12-console-application.h"

#include <iostream>
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

bool F(bool arg);
// The one and only application object

CWinApp theApp;

using namespace std;

int main()
{
	int nRetCode = 0;

	HMODULE hModule = ::GetModuleHandle(nullptr);

	if (hModule != nullptr)
	{
		// initialize MFC and print and error on failure
		if (!AfxWinInit(hModule, nullptr, ::GetCommandLine(), 0))
		{
			// TODO: code your application's behavior here.
			wprintf(L"Fatal Error: MFC initialization failed\n");
			nRetCode = 1;
		}
		else
		{
			// TODO: code your application's behavior here.
			try {
				CFile file(TEXT("a.txt"), CFile::modeRead);
				HBITMAP hBitmap = LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(40001));
				if (hBitmap == NULL)
					AfxThrowResourceException();
				file.Close();
			}
			catch (CFileException* pe) {
				TRACE("Casue: %d\n", pe->m_cause);

				TCHAR szCause[255];
				pe->GetErrorMessage(szCause, 255);
				TRACE("Error Message: %S\n", szCause);

				CFile file(TEXT("a.txt"), CFile::modeWrite | CFile::modeCreate);
				file.Close();

				pe->Delete();
			}
			catch (CResourceException* pe) {
				TCHAR szCause[255];
				pe->GetErrorMessage(szCause, 255);
				TRACE("Error Message: %S\n", szCause);
				throw; //rethrow exception
				// throw pe;
				pe->Delete();
			}
			

		}

	}
	else
	{
		// TODO: change error code to suit your needs
		wprintf(L"Fatal Error: GetModuleHandle failed\n");
		nRetCode = 1;
	}

	return nRetCode;
}


/*
	- While handling MFC exception using C++ exception handling keywords,
  ensure that Exception object is caught by address. Also ensure
  that the object is deleted at the end of the catch block.
-Filing to delete exception object result into excetion objcet leakage.

 

*/