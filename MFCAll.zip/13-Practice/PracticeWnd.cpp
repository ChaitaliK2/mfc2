#include "pch.h"
#include "PracticeWnd.h"
