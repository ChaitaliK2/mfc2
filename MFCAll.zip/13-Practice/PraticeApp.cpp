#include "pch.h"
#include "PraticeApp.h"
#include "PracticeWnd.h"

CPraticeApp theApp;

BOOL CPraticeApp::InitInstance()
{
	CPracticeWnd* pFrame = new CPracticeWnd();
	pFrame->Create(NULL, TEXT("This is my window"));
	pFrame->ShowWindow(m_nCmdShow);
	m_pMainWnd = pFrame;
	return TRUE;
}