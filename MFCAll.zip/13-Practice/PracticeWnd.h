#pragma once
class CPracticeWnd :
    public CFrameWnd
{
public:
    
};

