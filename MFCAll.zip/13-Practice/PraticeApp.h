#pragma once
class CPraticeApp :
    public CWinApp
{
public:
    BOOL InitInstance();
};

