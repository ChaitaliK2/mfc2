#pragma once
class CFirstHandCodedMFCApp :
    public CWinApp
{
public:
    BOOL InitInstance();
};

