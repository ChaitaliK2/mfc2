#include "pch.h"
#include "FirstHandCodedMFCApp.h"
#include "MainFrame.h"

CFirstHandCodedMFCApp theApp;

BOOL CFirstHandCodedMFCApp::InitInstance()
{
	CMainFrame* pFrame = new CMainFrame();
	pFrame->Create(NULL, TEXT("First Hand Coded MFC App "));
	pFrame->ShowWindow(m_nCmdShow);
	m_pMainWnd = pFrame;
	return TRUE;
}