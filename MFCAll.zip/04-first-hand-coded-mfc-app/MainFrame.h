#pragma once
class CMainFrame :
    public CFrameWnd
{
};

